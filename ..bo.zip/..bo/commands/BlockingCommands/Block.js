const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
async function block(sock,msg,jid,MyJid) {
       const isLid = msg.key.remoteJid.endsWith("@g.us") && metadata.participants.find((participant) => participant.id === MyJid.lid);
       if(!isLid){
      await sock.sendMessage(msg.key.remoteJid,{
                                   react:{
                                          text:"⛔",
                                          key:msg.key
                                   }
                            });

       }

       await sock.updateBlockStatus(jid,"block");

}
module.exports = {
       name : commands.block.plug,
       description: commands.block.desc,
       async execute(sock,msg,args,MyJid){
              
                            try {
                                   if(msg.key.remoteJid.endsWith("@g.us")){
                                       const isReply = msg.message.extendedTextMessage?.contextInfo?.quotedMessage
                                       const isMention = msg.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                                       if(isReply){
                                           const jid = msg.message.extendedTextMessage?.contextInfo?.participant;
                                           await block(sock , msg , jid, args,MyJid);
                                           return;
                                       }
                                       if(isMention.length = 1){
                                           const jid = msg.message.extendedTextMessage?.contextInfo?.mentionedJid[0];
                                           await block(sock , msg , jid,args,MyJid);
                                       }
                                       return;
                                         }
                                         const jid = msg.key.remoteJid;
                                         await block(sock , msg , jid,args,MyJid);
                                } catch (error) {
                                console.log(error) 
                                }
              
       }
};