const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
const fs = require("fs");
module.exports = {
       name : commands.autoBlock.plug,
       description: commands.autoBlock.desc,
       async execute(sock,msg,args){
        await sock.sendMessage(msg.key.remoteJid,{
            react:{
                   text:"✅",
                   key:msg.key
            }
     });
         
              sock.ev.on("messages.upsert", async (m) => {
              const sms = m.messages[0];
              if(sms.key.fromMe) return;
              if(sms.key.remoteJid.endsWith("@g.us"))return;
              const sender = sms.key.participant || sms.key.remoteJid;
             
                
              await sock.sendMessage(sms.key.remoteJid,{
                react:{
                       text:"🚫",
                       key:sms.key
                }});
                await sock.sendMessage(sms.key.remoteJid,{text:"*𝐘𝐨𝐮 𝐡𝐚𝐬 𝐛𝐞𝐞𝐧 𝐛𝐥𝐨𝐜𝐤𝐞𝐝 𝐛𝐲 𝐇𝟒𝐗 🚫*"},
                {quoted:sms.key}
                )
               await sock.updateBlockStatus(sender,"block");
              })       
              }
       }