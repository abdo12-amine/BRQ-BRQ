const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");
const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const fs = require('fs');
const path = require('path');

module.exports = {
    name: commands.antiViewOnce.plug,
    description: commands.antiViewOnce.desc,
    async execute(sock, msg, args) {
        try {
            if (!msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                return;
            }
            const quotedMsg = msg.message.extendedTextMessage.contextInfo;
            const quotedContent = quotedMsg.quotedMessage;
            let viewOnceContent = null;
            let isViewOnce = false;
            
            // التحقق من أنواع الرسائل ذات المشاهدة الواحدة
            if (quotedContent.viewOnceMessage) {
                viewOnceContent = quotedContent.viewOnceMessage.message;
                isViewOnce = true;
            } else if (quotedContent.viewOnceMessageV2) {
                viewOnceContent = quotedContent.viewOnceMessageV2.message;
                isViewOnce = true;
            } else if (quotedContent.ephemeralMessage) {
                viewOnceContent = quotedContent.ephemeralMessage.message;
                isViewOnce = true;
            } else {
                for (const key of Object.keys(quotedContent)) {
                    if (key.toLowerCase().includes('viewonce') || key.toLowerCase().includes('ephemeral')) {
                        viewOnceContent = quotedContent[key].message || quotedContent[key];
                        isViewOnce = true;
                        break;
                    }
                }
            }
            
            if (!isViewOnce) {
                viewOnceContent = quotedContent;
            }
            
            let mediaContent = null;
            let contentType = null;
            let mediaType = null;
            
            if (viewOnceContent) {
                contentType = Object.keys(viewOnceContent)[0];
                
                // تحديد نوع الوسائطavonce
                if (contentType === 'imageMessage') {
                    mediaContent = viewOnceContent;
                    mediaType = 'image';
                } else if (contentType === 'audioMessage' || contentType === 'pttMessage') {
                    mediaContent = viewOnceContent;
                    mediaType = 'audio';
                } else if (contentType === 'videoMessage') {
                    mediaContent = viewOnceContent;
                    mediaType = 'video';
                }
            }
            
            if (!mediaContent) {
                return;
            }
            
            const logger = {
                info: (...args) => console.log(...args),
                debug: (...args) => console.debug(...args),
                warn: (...args) => console.warn(...args),
                error: (...args) => console.error(...args)
            };
            
            try {
                // محاولة تنزيل الوسائط
                const buffer = await downloadMediaMessage(
                    {
                        key: {
                            remoteJid: msg.key.remoteJid,
                            id: quotedMsg.stanzaId
                        },
                        message: quotedContent
                    },
                    'buffer',
                    {},
                    {
                        logger,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
                
                // إرسال الوسائط حسب نوعها
                if (mediaType === 'image') {
                    await sock.sendMessage(msg.key.remoteJid, {
                        image: buffer,
                        caption: '> 𝙶𝚎𝚗𝚎𝚛𝚊𝚝𝚎𝚍 𝙱𝚢 : *𝗫 - 𝗠𝗢𝗗𝗭"*'
                    });
                } else if (mediaType === 'audio') {
                    const isPtt = contentType === 'pttMessage' || 
                                 (viewOnceContent.audioMessage && viewOnceContent.audioMessage.ptt);
                    
                    if (isPtt) {
                        await sock.sendMessage(msg.key.remoteJid, {
                            audio: buffer,
                            mimetype: 'audio/ogg; codecs=opus',
                            ptt: true
                        });
                    } else {
                        await sock.sendMessage(msg.key.remoteJid, {
                            audio: buffer,
                            mimetype: 'audio/mp4'
                        });
                    }
                } else if (mediaType === 'video') {
                    await sock.sendMessage(msg.key.remoteJid, {
                        video: buffer,
                        caption: '> 𝙶𝚎𝚗𝚎𝚛𝚊𝚝𝚎𝚍 𝙱𝚢 : *𝗫 - 𝗠𝗢𝗗𝗭"*'
                    });
                }
            } catch (downloadError) {
                console.log(downloadError);
                
                // محاولة تنزيل الوسائط من URL إذا كان متاحًا
                let url = null;
                
                if (mediaType === 'image' && mediaContent.imageMessage && mediaContent.imageMessage.url) {
                    url = mediaContent.imageMessage.url;
                    try {
                        await sock.sendMessage(msg.key.remoteJid, {
                            image: { url },
                            caption: '> 𝙶𝚎𝚗𝚎𝚛𝚊𝚝𝚎𝚍 𝙱𝚢 : *𝗫 - 𝗠𝗢𝗗𝗭"*'
                        });
                    } catch (urlError) {
                        throw new Error(urlError.message);
                    }
                } else if (mediaType === 'audio') {
                    if (mediaContent.audioMessage && mediaContent.audioMessage.url) {
                        url = mediaContent.audioMessage.url;
                    } else if (mediaContent.pttMessage && mediaContent.pttMessage.url) {
                        url = mediaContent.pttMessage.url;
                    }
                    
                    if (url) {
                        try {
                            const isPtt = contentType === 'pttMessage' || 
                                        (viewOnceContent.audioMessage && viewOnceContent.audioMessage.ptt);
                            
                            if (isPtt) {
                                await sock.sendMessage(msg.key.remoteJid, {
                                    audio: { url },
                                    mimetype: 'audio/ogg; codecs=opus',
                                    ptt: true
                                });
                            } else {
                                await sock.sendMessage(msg.key.remoteJid, {
                                    audio: { url },
                                    mimetype: 'audio/mp4'
                                });
                            }
                        } catch (urlError) {
                            throw new Error(urlError.message);
                        }
                    }
                } else if (mediaType === 'video' && mediaContent.videoMessage && mediaContent.videoMessage.url) {
                    url = mediaContent.videoMessage.url;
                    try {
                        await sock.sendMessage(msg.key.remoteJid, {
                            video: { url },
                            caption: '> 𝙶𝚎𝚗𝚎𝚛𝚊𝚝𝚎𝚍 𝙱𝚢 : *𝗫 - 𝗠𝗢𝗗𝗭"*'
                        });
                    } catch (urlError) {
                        throw new Error(urlError.message);
                    }
                } else {
                    throw new Error(downloadError.message);
                }
            }
            
        } catch (error) {
            console.log(error);
        }
    }
};