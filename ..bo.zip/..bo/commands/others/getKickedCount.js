const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
const fs = require('fs');


module.exports = {
    name: commands.getKickedCount.plug,
    description: commands.getKickedCount.desc,
    execute: async (sock, msg, args, myJid) => {
        try{
            const data = await fs.promises.readFile(paths.personalStatics,'utf8');
            const parsedData = JSON.parse(data);
            kickedCount = parsedData.CountOfKicked || 0 ;
            await sock.sendMessage(msg.key.remoteJid, 
                {text: `*Number of members Kicked is :* ${kickedCount}`},
                {quoted: msg}
            );
        }catch(error){
            console.error(error);
        }
    }}