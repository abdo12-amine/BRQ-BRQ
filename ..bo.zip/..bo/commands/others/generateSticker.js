const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");
const { Sticker, StickerTypes } = require('wa-sticker-formatter');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: commands.generateSticker.plug,
    description: commands.generateSticker.desc,
    async execute(sock, msg, args) {
        try {
            if (!args || args.length < 1) {
                return;
            }

            const fullInput = args.join(" ");
            const paramRegex = /\[(.*?)\]/g;
            const params = [];
            let match;
            
            while ((match = paramRegex.exec(fullInput)) !== null) {
                params.push(match[1]);
            }
            
            // استخراج النص الأساسي والمعلمات
            const text = params[0] || "نص افتراضي";
            
            // ألوان للاختيار منها
            const namedColors = {
                "red": "#FF0000",
                "green": "#00FF00",
                "blue": "#0000FF",
                "yellow": "#FFFF00",
                "cyan": "#00FFFF",
                "magenta": "#FF00FF",
                "black": "#000000",
                "white": "#FFFFFF",
                "gray": "#808080",
                "grey": "#808080",
                "purple": "#800080",
                "pink": "#FFC0CB",
                "orange": "#FFA500",
                "brown": "#A52A2A",
                "violet": "#8A2BE2",
                "gold": "#FFD700",
                "silver": "#C0C0C0",
                "navy": "#000080",
                "teal": "#008080",
                "maroon": "#800000",
                "lime": "#00FF00",
                "olive": "#808000",
                "aqua": "#00FFFF",
                "indigo": "#4B0082",
                "turquoise": "#40E0D0",
                "skyblue": "#87CEEB",
                "tomato": "#FF6347",
                "crimson": "#DC143C",
                "darkblue": "#00008B",
                "darkgreen": "#006400",
                "darkred": "#8B0000",
                "darkgray": "#A9A9A9",
                "darkgrey": "#A9A9A9",
                "lightgray": "#D3D3D3",
                "lightgrey": "#D3D3D3",
                "lightblue": "#ADD8E6",
                "lightgreen": "#90EE90",
                "lightred": "#FFCCCB",
                "transparent": "transparent"
            };
            
            // قوالب جاهزة يمكن الاختيار من بينها
            const presetStyles = {
                "default": {
                    textColor: "#000000",
                    bgColor: "#FFFFFF",
                    fontSize: 40,
                    fontFamily: "tajawal",
                    borderWidth: 0,
                    borderColor: "transparent",
                    shadowColor: "#666666",
                    shadowBlur: 2,
                    shadowOffsetX: 2,
                    shadowOffsetY: 2,
                    shape: "rounded",
                    textEffect: "none",
                    textOpacity: 1,
                    background: "solid"
                },
                "neon": {
                    textColor: "#FFFFFF",
                    bgColor: "#000000",
                    fontSize: 45,
                    fontFamily: "poppins",
                    borderWidth: 0,
                    borderColor: "transparent",
                    shadowColor: "#00FFFF",
                    shadowBlur: 5,
                    shadowOffsetX: 0,
                    shadowOffsetY: 0,
                    shape: "rounded",
                    textEffect: "glow",
                    textOpacity: 1,
                    background: "solid"
                },
                "vintage": {
                    textColor: "#8B4513",
                    bgColor: "#F5F5DC",
                    fontSize: 35,
                    fontFamily: "playfair",
                    borderWidth: 2,
                    borderColor: "#8B4513",
                    shadowColor: "#B38D6A",
                    shadowBlur: 1,
                    shadowOffsetX: 1,
                    shadowOffsetY: 1,
                    shape: "square",
                    textEffect: "distressed",
                    textOpacity: 0.9,
                    background: "paper"
                },
                "minimal": {
                    textColor: "#333333",
                    bgColor: "#FFFFFF",
                    fontSize: 38,
                    fontFamily: "montserrat",
                    borderWidth: 0,
                    borderColor: "transparent",
                    shadowColor: "transparent",
                    shadowBlur: 0,
                    shadowOffsetX: 0,
                    shadowOffsetY: 0,
                    shape: "rounded",
                    textEffect: "none",
                    textOpacity: 1,
                    background: "solid"
                },
                "elegant": {
                    textColor: "#333333",
                    bgColor: "#F0F0F0",
                    fontSize: 36,
                    fontFamily: "merriweather",
                    borderWidth: 1,
                    borderColor: "#CCCCCC",
                    shadowColor: "#E5E5E5",
                    shadowBlur: 1,
                    shadowOffsetX: 1,
                    shadowOffsetY: 1,
                    shape: "rounded",
                    textEffect: "none",
                    textOpacity: 1,
                    background: "solid"
                },
                "bold": {
                    textColor: "#FFFFFF",
                    bgColor: "#FF5722",
                    fontSize: 50,
                    fontFamily: "oswald",
                    borderWidth: 0,
                    borderColor: "transparent",
                    shadowColor: "#994035",
                    shadowBlur: 3,
                    shadowOffsetX: 1,
                    shadowOffsetY: 1,
                    shape: "rounded",
                    textEffect: "none",
                    textOpacity: 1,
                    background: "solid"
                },
                "dark": {
                    textColor: "#FFFFFF",
                    bgColor: "#333333",
                    fontSize: 40,
                    fontFamily: "roboto",
                    borderWidth: 0,
                    borderColor: "transparent",
                    shadowColor: "#1A1A1A",
                    shadowBlur: 2,
                    shadowOffsetX: 1,
                    shadowOffsetY: 1,
                    shape: "rounded",
                    textEffect: "none",
                    textOpacity: 1,
                    background: "solid"
                }
            };
            
            // الخطوط المتاحة
            const fonts = {
                // Arabic Fonts
                "amiri": "'Amiri', serif",
                "tajawal": "'Tajawal', sans-serif",
                "cairo": "'Cairo', sans-serif",
                "scheherazade": "'Scheherazade', serif",
                "harmattan": "'Harmattan', sans-serif",
                "dubai": "'Dubai', sans-serif",
                "noto": "'Noto Sans Arabic', sans-serif",
                "droid": "'Droid Arabic Naskh', serif",
                
                // English Fonts
                "roboto": "'Roboto', sans-serif",
                "opensans": "'Open Sans', sans-serif",
                "lato": "'Lato', sans-serif",
                "montserrat": "'Montserrat', sans-serif",
                "poppins": "'Poppins', sans-serif",
                "raleway": "'Raleway', sans-serif",
                "ubuntu": "'Ubuntu', sans-serif",
                "playfair": "'Playfair Display', serif",
                "merriweather": "'Merriweather', serif",
                "sourcesans": "'Source Sans Pro', sans-serif",
                "oswald": "'Oswald', sans-serif",
                "comicsans": "'Comic Sans MS', cursive",
                "times": "'Times New Roman', serif",
                "georgia": "'Georgia', serif",
                "helvetica": "'Helvetica', sans-serif",
                "arial": "'Arial', sans-serif",
                "verdana": "'Verdana', sans-serif"
            };
            
            // الأشكال المتاحة للخلفية
            const shapes = {
                "rounded": { rx: 30, ry: 30 },
                "square": { rx: 0, ry: 0 },
                "circle": { rx: 256, ry: 256 },
                "oval": { rx: 256, ry: 150 },
                "roundedsquare": { rx: 15, ry: 15 }
            };
            
            // وظائف مساعدة للتحقق من الألوان والتحويل
            function getColorCode(color) {
                if (!color) return null;
                
                if (color.startsWith('#')) {
                    return color;
                }
                
                const colorLower = color.toLowerCase();
                
                if (namedColors[colorLower]) {
                    return namedColors[colorLower];
                }
                
                return "#000000";
            }
            
            // التحقق من وجود اللغة العربية في النص
            function containsArabic(text) {
                const arabicPattern = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
                return arabicPattern.test(text);
            }
            
            // تأمين النص من أخطاء XML
            function escapeXml(unsafe) {
                return unsafe
                    .replace(/&/g, "&amp;")
                    .replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;")
                    .replace(/"/g, "&quot;")
                    .replace(/'/g, "&apos;");
            }
            
            // تقسيم النص إلى أسطر متعددة
            function wrapText(text, maxCharsPerLine) {
                const adjustedMaxChars = Math.floor(maxCharsPerLine * 0.8);
                const words = text.split(' ');
                const lines = [];
                let currentLine = '';

                words.forEach(word => {
                    if (currentLine.length + word.length > adjustedMaxChars) {
                        if (currentLine.length > 0) {
                            lines.push(currentLine);
                            currentLine = word;
                        } else {
                            lines.push(word);
                            currentLine = '';
                        }
                    } else {
                        if (currentLine.length > 0) {
                            currentLine += ' ' + word;
                        } else {
                            currentLine = word;
                        }
                    }
                });

                if (currentLine.length > 0) {
                    lines.push(currentLine);
                }

                return lines;
            }
            
            // تقديم تاريخ ووقت محلي
            function getLocalDateTime() {
                const now = new Date();
                return now.toLocaleString('ar-SA');
            }
            
            // التحقق ما إذا كان المستخدم قد اختار قالبًا
            const presetName = params[1] ? params[1].toLowerCase() : "default";
            const selectedPreset = presetStyles[presetName] || presetStyles["default"];
            
            // استخراج المعلمات من المدخلات أو استخدام القالب الافتراضي
            const textColor = params[2] ? getColorCode(params[2]) : selectedPreset.textColor;
            const bgColor = params[3] ? getColorCode(params[3]) : selectedPreset.bgColor;
            const fontSize = params[4] ? parseInt(params[4]) : selectedPreset.fontSize;
            
            let fontFamily = params[5] ? params[5].toLowerCase() : selectedPreset.fontFamily;
            if (!fonts[fontFamily]) {
                fontFamily = selectedPreset.fontFamily;
            } else {
                fontFamily = fonts[fontFamily];
            }
            
            // معلمات متقدمة
            const borderWidth = params[6] ? parseInt(params[6]) : selectedPreset.borderWidth;
            const borderColor = params[7] ? getColorCode(params[7]) : selectedPreset.borderColor;
            const shadowBlur = params[8] ? parseInt(params[8]) : selectedPreset.shadowBlur;
            const shadowColor = params[9] ? getColorCode(params[9]) : selectedPreset.shadowColor;
            const shadowOffsetX = params[10] ? parseInt(params[10]) : selectedPreset.shadowOffsetX;
            const shadowOffsetY = params[11] ? parseInt(params[11]) : selectedPreset.shadowOffsetY;
            
            // شكل الخلفية
            const shapeName = params[12] ? params[12].toLowerCase() : selectedPreset.shape;
            const shapeConfig = shapes[shapeName] || shapes["rounded"];
            
            // تأثيرات إضافية
            const textEffect = params[13] ? params[13].toLowerCase() : selectedPreset.textEffect;
            const textOpacity = params[14] ? parseFloat(params[14]) : selectedPreset.textOpacity;
            const backgroundStyle = params[15] ? params[15].toLowerCase() : selectedPreset.background;
            
            // إضافة رمز تعبيري (إيموجي)
            const emoji = params[16] || "";
            
            // تحديد اتجاه النص بناءً على اللغة
            const isArabic = containsArabic(text);
            const textDirection = isArabic ? "rtl" : "ltr";
            const unicodeBidi = isArabic ? "bidi-override" : "normal";
            
            // حساب حجم النص وتقسيمه إلى أسطر
            const maxCharsPerLine = Math.floor(400 / (fontSize * 0.6));
            const lines = wrapText(text, maxCharsPerLine);
            
            // إنشاء عناصر النص
            let textElements = '';
            const lineHeight = fontSize * 1.3;
            const totalHeight = lines.length * lineHeight;
            const startY = 256 - (totalHeight / 2) + (lineHeight / 2);
            
            // إنشاء فلاتر خاصة بالتأثيرات
            let filterEffects = `
                <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
                    <feDropShadow dx="${shadowOffsetX}" dy="${shadowOffsetY}" stdDeviation="${shadowBlur}" flood-color="${shadowColor}" flood-opacity="1" />
                </filter>
            `;
            
            // إضافة تأثيرات نصية مخصصة
            if (textEffect === "glow") {
                filterEffects += `
                    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                        <feGaussianBlur stdDeviation="3.5" result="blur" />
                        <feMerge>
                            <feMergeNode in="blur" />
                            <feMergeNode in="SourceGraphic" />
                        </feMerge>
                    </filter>
                `;
            } else if (textEffect === "distressed") {
                filterEffects += `
                    <filter id="distressed" x="0%" y="0%" width="100%" height="100%">
                        <feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves="3" seed="1" />
                        <feDisplacementMap in="SourceGraphic" scale="5" />
                    </filter>
                `;
            } else if (textEffect === "outline") {
                filterEffects += `
                    <filter id="outline" x="-10%" y="-10%" width="120%" height="120%">
                        <feMorphology operator="dilate" radius="1" result="expanded" />
                        <feFlood flood-color="${textColor}" flood-opacity="1" result="color" />
                        <feComposite in="color" in2="expanded" operator="in" result="outline" />
                        <feComposite in="SourceGraphic" in2="outline" operator="over" />
                    </filter>
                `;
            }
            
            // إضافة خلفية خاصة
            let backgroundEffect = '';
            if (backgroundStyle === "paper") {
                backgroundEffect = `
                    <filter id="paper" x="0%" y="0%" width="100%" height="100%">
                        <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="5" seed="1" result="noise" />
                        <feColorMatrix type="matrix" values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 0.3 0" result="colorNoise" />
                        <feBlend in="SourceGraphic" in2="colorNoise" mode="multiply" />
                    </filter>
                `;
            } else if (backgroundStyle === "gradient") {
                backgroundEffect = `
                    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stop-color="${bgColor}" />
                        <stop offset="100%" stop-color="${shadowColor}" />
                    </linearGradient>
                `;
            }
            
            // إضافة تأثير للنص بناءً على الاختيار
            let textFilterId = "shadow";
            if (textEffect === "glow") {
                textFilterId = "glow";
            } else if (textEffect === "distressed") {
                textFilterId = "distressed";
            } else if (textEffect === "outline") {
                textFilterId = "outline";
            }
            
            // صياغة عناصر النص مع التأثيرات المختارة
            lines.forEach((line, index) => {
                const yPosition = startY + (index * lineHeight);
                const escapedLine = escapeXml(line);
                textElements += `
                <text 
                    x="50%" 
                    y="${yPosition}" 
                    font-family="${fontFamily}" 
                    font-size="${fontSize}" 
                    fill="${textColor}" 
                    fill-opacity="${textOpacity}"
                    text-anchor="middle" 
                    dominant-baseline="middle"
                    filter="url(#${textFilterId})"
                    font-weight="bold"
                    direction="${textDirection}"
                    unicode-bidi="${unicodeBidi}"
                >${escapedLine}</text>`;
            });
            
            // إضافة إيموجي إذا كان موجودًا
            let emojiElement = '';
            if (emoji) {
                emojiElement = `
                <text 
                    x="430" 
                    y="70" 
                    font-family="Arial" 
                    font-size="50" 
                    text-anchor="middle" 
                    dominant-baseline="middle"
                >${emoji}</text>
                `;
            }
            
            // إضافة الوقت والتاريخ إذا طلب المستخدم ذلك
            let dateTimeElement = '';
            if (params.includes("showdate") || params.includes("showtime")) {
                dateTimeElement = `
                <text 
                    x="50%" 
                    y="${startY + totalHeight + 40}" 
                    font-family="${fontFamily}" 
                    font-size="${Math.floor(fontSize * 0.6)}" 
                    fill="${textColor}" 
                    fill-opacity="0.7"
                    text-anchor="middle" 
                    dominant-baseline="middle"
                >${getLocalDateTime()}</text>
                `;
            }
            
            // تحديد لون الخلفية بناءً على النمط المختار
            let fillAttribute = bgColor;
            if (backgroundStyle === "gradient") {
                fillAttribute = "url(#grad)";
            }
            
            // إنشاء محتوى SVG الكامل
            const svgContent = `
            <svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <style type="text/css">
                        @import url('https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&amp;family=Cairo:wght@400;700&amp;family=Harmattan:wght@400;700&amp;family=Scheherazade:wght@400;700&amp;family=Tajawal:wght@400;700&amp;family=Roboto:wght@400;700&amp;family=Open+Sans:wght@400;700&amp;family=Lato:wght@400;700&amp;family=Montserrat:wght@400;700&amp;family=Poppins:wght@400;700&amp;family=Raleway:wght@400;700&amp;family=Ubuntu:wght@400;700&amp;family=Playfair+Display:wght@400;700&amp;family=Merriweather:wght@400;700&amp;family=Source+Sans+Pro:wght@400;700&amp;family=Oswald:wght@400;700&amp;display=swap');
                    </style>
                    ${filterEffects}
                    ${backgroundEffect}
                </defs>
                
                <rect width="100%" height="100%" fill="${fillAttribute}" rx="${shapeConfig.rx}" ry="${shapeConfig.ry}" ${backgroundStyle === "paper" ? 'filter="url(#paper)"' : ''} />
                
                ${borderWidth > 0 ? `<rect x="${borderWidth/2}" y="${borderWidth/2}" width="${512-borderWidth}" height="${512-borderWidth}" fill="none" stroke="${borderColor}" stroke-width="${borderWidth}" rx="${shapeConfig.rx}" ry="${shapeConfig.ry}" />` : ''}
                
                ${textElements}
                ${emojiElement}
                
                <line 
                    x1="128" 
                    y1="${startY + totalHeight + 20}" 
                    x2="384" 
                    y2="${startY + totalHeight + 20}" 
                    stroke="${textColor}" 
                    stroke-opacity="0.5" 
                    stroke-width="3" 
                    stroke-linecap="round"
                />
                
                ${dateTimeElement}
            </svg>
            `;

            // حفظ الملف وإنشاء الملصق
            const tempDir = path.join(__dirname, '../../temp');
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
            }

            const timestamp = Date.now();
            const svgPath = path.join(tempDir, `text_${timestamp}.svg`);
            fs.writeFileSync(svgPath, svgContent);

            const sticker = new Sticker(svgPath, {
                pack: textuals.stikerMaker.right,
                author: textuals.stikerMaker.right,
                type: StickerTypes.FULL,
                categories: ['🤩', '🎉'],
                quality: 100,
                background: 'transparent'
            });
            
            const stickerBuffer = await sticker.toBuffer();
            
            // إرسال الملصق
            await sock.sendMessage(msg.key.remoteJid, {
                sticker: stickerBuffer
            });
            
            // تنظيف الملفات المؤقتة
            fs.unlink(svgPath, (err) => {
                if (err) console.error("Error deleting temp SVG file:", err);
            });
            
        } catch (error) {
            console.error("Error in text sticker creation:", error);
        }
    }
};