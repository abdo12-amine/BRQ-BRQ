const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
const fs = require("fs");
module.exports = {
       name : commands.monite.plug,
       description: commands.monite.desc,
       async execute(sock,msg,args,MyJid){
              if(msg.key.remoteJid.endsWith("@g.us")){
                     try {
                        let currentElites = [];
                        const data = await fs.promises.readFile("resources/dataFiles/elites.json",'utf8');
                        const parsedData = JSON.parse(data);
                        const targetgroup = await sock.groupMetadata(msg.key.remoteJid);
                        const targetgroupJid = targetgroup.id;
                        const participantsJids = targetgroup.participants.map(p => p.id);
                        const adminsJid = targetgroup.participants.filter(p => p.admin).map(admin => admin.id);
                        for (const participant of participantsJids) {
                            if(parsedData.includes(participant)){
                                currentElites.push(participant);
                                if(!adminsJid.includes(participant)){
                                   await sock.groupParticipantsUpdate(targetgroupJid, [participant], "promote");  
                                }
                               
                            }else{
                                if(adminsJid.includes(participant)){
                                    await sock.groupParticipantsUpdate(targetgroupJid, [participant], "demote");
                                }else{};
                            }
                        }

                        await sock.sendMessage(msg.key.remoteJid,{text:"Moniting is activated ✅"});
                        sock.ev.on("group-participants.update", async ({ id, participants, action , author}) =>  {
                        if(targetgroupJid !== id)return;
                        if(action === "demote"){
                            if(currentElites.includes(participants[0])){
                                await sock.sendMessage(id,{text:"*⚠️:* 𝘁𝗵𝗶𝘀 𝗴𝗿𝗼𝘂𝗽 𝘄𝗶𝗹𝗹 𝗯𝗲 𝗱𝗲𝘀𝘁𝗿𝗼𝘆𝗲𝗱 𝗯𝗲𝗰𝗮𝘂𝘀𝗲 𝗼𝗻𝗲 𝗼𝗳 𝘁𝗵𝗲 𝗲𝗹𝗶𝘁𝗲𝘀 𝗵𝗮𝘀 𝗯𝗲𝗲𝗻 𝗱𝗲𝗺𝗼𝘁𝗲𝗱."});
                                const metadata = await sock.groupMetadata(id);
                                const toKick = metadata.participants
                                .filter((p) => p.id !== MyJid && !parsedData.includes(p.id)).map((p) => p.id);
                                if(toKick.length === 0)return;
                                await sock.groupParticipantsUpdate(id,toKick,"remove");
                                return;
                            }
                        }
                        if(action === "remove"){
                            if(currentElites.includes(participants[0])){
                                await sock.sendMessage(id,{text:"*⚠️:* 𝗘𝗹𝗶𝘁𝗲 𝗵𝗮𝘀 𝗯𝗲𝗲𝗻 𝗸𝗶𝗰𝗸𝗲𝗱 𝗳𝗿𝗼𝗺 𝘁𝗵𝗲 𝘁𝗮𝗿𝗴𝗲𝘁 𝗴𝗿𝗼𝘂𝗽."});
                                currentElites.splice(currentElites.indexOf(participants[0]),1);
                                const metadata = await sock.groupMetadata(id);
                                const toKick = metadata.participants
                                .filter((p) => p.id !== MyJid && !parsedData.includes(p.id)).map((p) => p.id);
                                if(toKick.length === 0)return;
                                await sock.groupParticipantsUpdate(id,toKick,"remove");
                            }
                        }
                           
                        });
                     } catch (error) {
                     console.log(error) 
                     }
                     
              };

       }
}; 