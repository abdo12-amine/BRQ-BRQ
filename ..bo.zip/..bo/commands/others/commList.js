const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
module.exports = {
    name: commands.commList.plug,
    description: commands.commList.desc,
    async execute(sock, msg, args) {
        try {
            // Dynamic import of commands
            const commands = require('../../resources/commands');
            
            // Create formatted message
            let commandsList = " *𝘽𝙤𝙩 𝙛𝙪𝙡𝙡 𝙘𝙤𝙢𝙢𝙖𝙣𝙙𝙨 :*\n\n";
           
            
            // Sort commands alphabetically
            const sortedCommands = Object.entries(commands)
                .sort(([a], [b]) => a.localeCompare(b));
             commandsList += ` *𝐍𝐮𝐦𝐛𝐞𝐫 :* ${sortedCommands.length}\n\n`;
            // Add each command to the message
            sortedCommands.forEach(([name, details]) => {
                // Ensure compatibility with plug/Plug variations
                const plug = details.plug || details.Plug;
                commandsList += `> *${name} :*\n\n`;
                commandsList += ` 𑁌 𝐂𝐨𝐦𝐦𝐚𝐧𝐝  : \`${plug}\`\n`;
                commandsList += ` 𑁌 𝐃𝐞𝐬𝐜𝐫𝐢𝐩𝐭𝐢𝐨𝐧 : ${details.desc}\n\n`;
            });
        
            
            // Send commands list
            await sock.sendMessage(msg.key.remoteJid, {
                text: commandsList
            });
        } catch (error) {
            console.error("Error retrieving commands list:", error);
            
        }
    }
};