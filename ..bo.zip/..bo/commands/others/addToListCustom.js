// Command 1: Add user to JSON file with nickname
const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
const fs = require('fs').promises;
const path = require('path');

module.exports = {
    name: commands.addToListCustom.plug,
    description: commands.addToListCustom.desc,
    async execute(sock, msg, args) {
        // Check if it's a reply
        if (!msg.message?.extendedTextMessage?.contextInfo) {
            return;
        }
        if (args.length === 0) {
            return;
        }
        
        try {
            const userJid = msg.message.extendedTextMessage.contextInfo.participant;
            const nickname = args.join(" ");
            const contactsPath = path.join(__dirname, paths.contacts);
            let contacts = {};
            try {
                const fileData = await fs.readFile(contactsPath, 'utf8');
                contacts = JSON.parse(fileData);
                await sock.sendMessage(msg.key.remoteJid, { react: { text: "✅", key: msg.key } });
            } catch (error) {
                console.error(error);
            }
            if (contacts[nickname]) {
                return;
            }
            contacts[nickname] = userJid;
            await fs.writeFile(contactsPath, JSON.stringify(contacts, null, 2), 'utf8');
        } catch (error) {
            console.error(error);
        }
    }
};