const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
module.exports = {
       name : commands.testBot.plug,
       description: commands.testBot.desc,
       async execute(sock,msg,args,MyJid){
                     try {
                     await sock.sendMessage(msg.key.remoteJid, {
                            text: textuals.testBot.text,
                        }, {
                            quoted: msg
                     })
                     } catch (error) {
                     console.log(error) 
                     }
       }
}