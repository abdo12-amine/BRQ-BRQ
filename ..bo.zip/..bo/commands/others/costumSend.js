const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
const fs = require('fs').promises;
const path = require('path');
const { downloadMediaMessage } = require("@whiskeysockets/baileys");

module.exports = {
    name: commands.costumSend.plug, // or whatever command name you prefer
    description: commands.costumSend.desc,
    async execute(sock, msg, args) {
        if (!msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
            return;
        }
        
        // Check if nickname is provided
        if (args.length === 0) {
            return;
        }
        try {
            const nickname = args[0];
            const contactsPath = path.join(__dirname, paths.contacts);
            let contacts = {};
            try {
                const fileData = await fs.readFile(contactsPath, 'utf8');
                contacts = JSON.parse(fileData);
            } catch (error) {
                return;
            }
            if (!contacts[nickname]) {
                return;
            }
            const userJid = contacts[nickname];
            const quotedMsg = msg.message.extendedTextMessage.contextInfo.quotedMessage;
            const quotedMsgType = Object.keys(quotedMsg)[0];
            const message = {
                key: {
                    remoteJid: msg.key.remoteJid,
                    id: msg.message.extendedTextMessage.contextInfo.stanzaId
                },
                message: quotedMsg
            };
            let messageToSend = {};
            switch (quotedMsgType) {
                case 'conversation':
                case 'extendedTextMessage':
                    messageToSend = {
                        text: quotedMsg[quotedMsgType].text || quotedMsg[quotedMsgType],
                        contextInfo: {
                            isForwarded: true,
                            forwardingScore: 1
                        }
                    };
                    break;
                    
                case 'imageMessage':
                    try {
                        const buffer = await downloadMediaMessage(
                            message,
                            'buffer',
                            {},
                            { logger, reuploadRequest: sock.updateMediaMessage }
                        );
                        
                        messageToSend = {
                            image: buffer,
                            caption: quotedMsg[quotedMsgType].caption || '',
                            contextInfo: {
                                isForwarded: true,
                                forwardingScore: 1
                            }
                        };
                    } catch (e) {
                        console.error(e);
                        return;
                    }
                    break;
                    
                case 'videoMessage':
                    try {
                        const buffer = await downloadMediaMessage(
                            message,
                            'buffer',
                            {},
                            { logger, reuploadRequest: sock.updateMediaMessage }
                        );
                        
                        messageToSend = {
                            video: buffer,
                            caption: quotedMsg[quotedMsgType].caption || '',
                            contextInfo: {
                                isForwarded: true,
                                forwardingScore: 1
                            }
                        };
                    } catch (e) {
                        console.error("Error downloading video:", e);
                        return;
                    }
                    break;
                    
                case 'audioMessage':
                    try {
                        const buffer = await downloadMediaMessage(
                            message,
                            'buffer',
                            {},
                            { logger, reuploadRequest: sock.updateMediaMessage }
                        );
                        
                        messageToSend = {
                            audio: buffer,
                            mimetype: 'audio/mp4',
                            ptt: quotedMsg[quotedMsgType].ptt || false,
                            contextInfo: {
                                isForwarded: true,
                                forwardingScore: 1
                            }
                        };
                    } catch (e) {
                        console.error(e);
                        return;
                    }
                    break;
                    
                case 'stickerMessage':
                    try {
                        const buffer = await downloadMediaMessage(
                            message,
                            'buffer',
                            {},
                            { logger, reuploadRequest: sock.updateMediaMessage }
                        );
                        
                        messageToSend = {
                            sticker: buffer,
                            contextInfo: {
                                isForwarded: true,
                                forwardingScore: 1
                            }
                        };
                    } catch (e) {
                        console.error(e);
                        return;
                    }
                    break;
                    
                default:
                    return;
            }
            await sock.sendMessage(userJid, messageToSend);
            let sentTypeMsg = "رسالة نصية";
            if (quotedMsgType === 'imageMessage') sentTypeMsg = "صورة";
            if (quotedMsgType === 'videoMessage') sentTypeMsg = "فيديو";
            if (quotedMsgType === 'audioMessage') sentTypeMsg = "رسالة صوتية";
            if (quotedMsgType === 'stickerMessage') sentTypeMsg = "ملصق";
        } catch (error) {
            console.error(error);
        }
    }
};