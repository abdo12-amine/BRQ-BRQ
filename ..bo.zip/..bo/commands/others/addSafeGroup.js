const fs = require('fs').promises;
const path = require("path");
const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");

module.exports = {
       name: commands.addGbToSafeList.plug,
       description: commands.addGbToSafeList.desc,
       async execute(sock, msg, args) {
              try {
                     const safeGroupsPath = path.join(__dirname, "../../resources/dataFiles/safeGroups.json");
                     let safeGroups = [];
                     try {
                            await fs.access(safeGroupsPath);
                            const fileData = await fs.readFile(safeGroupsPath, 'utf8');
                            safeGroups = JSON.parse(fileData);
                     } catch (error) {
                     }
                     const groupJid = msg.key.remoteJid;
                     if (!safeGroups.includes(groupJid)) {
                            safeGroups.push(groupJid);
                            await fs.writeFile(safeGroupsPath, JSON.stringify(safeGroups, null, 2), 'utf8');
                            await sock.sendMessage(msg.key.remoteJid, { react: { text: "✅", key: msg.key } });
                     }
              } catch (error) {
                     console.error(error);
              }
       }
};
