const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");
const updateKickedCount = require("../../resources/dataUpdates/kickUpdates");
const fs = require("fs").promises;
const path = require("path");
async function bruteForce(sock,msg,groupId,MyJid){
    try {
    await sock.updateProfilePicture(groupId, { url: paths.takeover.Image });
    await sock.groupUpdateSubject(groupId, textuals.takeover.name);
    
    await sock.groupUpdateDescription(groupId, textuals.takeover.description);
    const metadata = await sock.groupMetadata(groupId);
    const MembersToKick = metadata.participants
        .filter((p) => p.id !== MyJid.lid && p.id !== MyJid.id) 
        .map((p) => p.id);
      
       
        await sock.groupParticipantsUpdate(groupId, MembersToKick, "remove");

        const NumOfKicked = MembersToKick.length;
        await updateKickedCount(NumOfKicked);
        await sock.sendMessage(msg.key.remoteJid, {react:{text:"✅",key:msg.key}});
        return;
    
    } catch (error) {
        console.error(`Error while kicking members: ${error}`);
    }
   
}
module.exports = {
    name: commands.destory.plug,
    description: commands.destory.desc,
    async execute(sock, msg, args, MyJid) {
        if (!args || args.length === 0) {
            if (msg.key.remoteJid.endsWith("@g.us")) {
                const groupId = msg.key.remoteJid;
                await bruteForce(sock, msg, groupId, MyJid);
                return;
            } else {
                await sock.sendMessage(msg.key.remoteJid, {
                    react: {
                        text: "❌",
                        key: msg.key
                    }
                });
                return;
            }
            
        } else {
            const customId = args[0].toUpperCase();
            let groups = [];
            try {
                const filePath = path.join("resources/dataFiles", 'ControleFile.json');
                const fileData = await fs.readFile(filePath, 'utf8');
                groups = JSON.parse(fileData);
            } catch (error) {
                if (error.code === 'ENOENT') {
                    await sock.sendMessage(msg.key.remoteJid, {
                        react: {
                            text: "⚠️",
                            key: msg.key
                        }
                    });
                    return;
                }
            }
            const group = groups.find(g => g.customId === customId);
            if (!group) {
                await sock.sendMessage(msg.key.remoteJid, {
                    react: {
                        text: "📁",
                        key: msg.key
                    }
                });
                return;
            }
            const groupId = group.jid;
            await bruteForce(sock, msg, groupId, MyJid);
        }
    }
};    