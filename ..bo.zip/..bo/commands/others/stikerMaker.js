const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");
const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const { Sticker, StickerTypes } = require('wa-sticker-formatter');
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const ffmpeg = require('fluent-ffmpeg');
const { promisify } = require('util');
const execPromise = promisify(exec);

// الحد الأقصى لحجم الملف بالميجابايت
const MAX_FILE_SIZE_MB = 1;

module.exports = {
    name: commands.stikerMaker.plug,
    description: commands.stikerMaker.desc,
    async execute(sock, msg, args) {
        if (!msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
            return;
        }
        
        try {
            const quotedMsg = msg.message.extendedTextMessage.contextInfo;
            const quotedMessage = quotedMsg.quotedMessage;
            let mediaType = null;
            if (quotedMessage.imageMessage) mediaType = 'image';
            else if (quotedMessage.videoMessage) mediaType = 'video';
            else if (quotedMessage.documentMessage &&
                     quotedMessage.documentMessage.mimetype === 'image/gif') mediaType = 'gif';
                    
            if (!mediaType) {
                return;
            }
            
            const logger = {
                info: (...args) => console.log(...args),
                debug: (...args) => console.debug(...args),
                warn: (...args) => console.warn(...args),
                error: (...args) => console.error(...args)
            };
            
            // إعداد رسالة للتحميل
            const message = {
                key: {
                    remoteJid: msg.key.remoteJid,
                    id: quotedMsg.stanzaId
                },
                message: quotedMessage
            };
            const buffer = await downloadMediaMessage(
                message,
                'buffer',
                {},
                {
                    logger,
                    reuploadRequest: sock.updateMediaMessage
                }
            );
            
            // حجم الملف بالميجابايت
            const fileSizeMB = buffer.length / (1024 * 1024);
            console.log(`Original file size: ${fileSizeMB.toFixed(2)} MB`);
            
            let processedBuffer = buffer;
            
            // معالجة الوسائط حسب نوعها
            if (mediaType === 'image') {
                try {
                    const imageMetadata = await sharp(buffer).metadata();
                    if (imageMetadata.width !== imageMetadata.height) {
                        const minDimension = Math.min(imageMetadata.width, imageMetadata.height);
                        
                        // تحديد الحجم المناسب للصورة (تقليل الأبعاد إذا كانت كبيرة جدًا)
                        const targetSize = Math.min(minDimension, 512);
                        
                        processedBuffer = await sharp(buffer)
                            .resize({
                                width: targetSize,
                                height: targetSize,
                                fit: 'cover',
                                position: 'center'
                            })
                            .jpeg({ quality: 80 }) // ضغط الصورة
                            .toBuffer();
                    } else {
                        // إذا كانت الصورة مربعة بالفعل، نقوم فقط بتقليل أبعادها وضغطها
                        const targetSize = Math.min(imageMetadata.width, 512);
                        
                        processedBuffer = await sharp(buffer)
                            .resize(targetSize, targetSize)
                            .jpeg({ quality: 80 })
                            .toBuffer();
                    }
                } catch (sharpError) {
                    console.error("Error processing image:", sharpError);
                }
            } else if (mediaType === 'video' || mediaType === 'gif') {
                // معالجة الفيديو أو GIF لجعله مربعًا وتحديد مدته وتقليل حجمه
                try {
                    // إنشاء مجلد مؤقت إذا لم يكن موجودًا
                    const tempDir = path.join(__dirname, '../../temp');
                    if (!fs.existsSync(tempDir)) {
                        fs.mkdirSync(tempDir, { recursive: true });
                    }
                    
                    // حفظ الملف المؤقت
                    const tempInputPath = path.join(tempDir, `input_${Date.now()}.${mediaType === 'gif' ? 'gif' : 'mp4'}`);
                    const tempCroppedPath = path.join(tempDir, `cropped_${Date.now()}.${mediaType === 'gif' ? 'gif' : 'mp4'}`);
                    const tempDurationPath = path.join(tempDir, `duration_${Date.now()}.${mediaType === 'gif' ? 'gif' : 'mp4'}`);
                    const tempOutputPath = path.join(tempDir, `output_${Date.now()}.${mediaType === 'gif' ? 'gif' : 'mp4'}`);
                    
                    fs.writeFileSync(tempInputPath, buffer);
                    
                    // الحصول على معلومات الفيديو
                    const { stdout: videoInfo } = await execPromise(`ffprobe -v error -select_streams v:0 -show_entries stream=width,height,duration -of csv=s=x:p=0 "${tempInputPath}"`);
                    const videoInfoParts = videoInfo.trim().split('x');
                    const width = parseInt(videoInfoParts[0]);
                    const height = parseInt(videoInfoParts[1]);
                    
                    // قد تتضمن معلومات المدة في الجزء الثالث، إذا كانت متاحة
                    let duration = videoInfoParts.length > 2 ? parseFloat(videoInfoParts[2]) : null;
                    
                    // إذا لم نحصل على المدة من الأمر السابق، نستخدم أمرًا مختلفًا
                    if (!duration) {
                        const { stdout: durationInfo } = await execPromise(`ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${tempInputPath}"`);
                        duration = parseFloat(durationInfo.trim());
                    }
                    
                    console.log(`Video dimensions: ${width}x${height}, Duration: ${duration} seconds`);
                    
                    // حساب أبعاد القص
                    const minDimension = Math.min(width, height);
                    const cropX = Math.floor((width - minDimension) / 2);
                    const cropY = Math.floor((height - minDimension) / 2);
                    
                    // تحديد الحجم المستهدف (تقليل الأبعاد إذا كانت كبيرة جدًا)
                    const targetSize = Math.min(minDimension, 256); // حجم أصغر للفيديو
                    
                    // قص الفيديو وتغيير حجمه ليكون مربعًا
                    await new Promise((resolve, reject) => {
                        ffmpeg(tempInputPath)
                            .videoFilters([
                                `crop=${minDimension}:${minDimension}:${cropX}:${cropY}`,
                                `scale=${targetSize}:${targetSize}`
                            ])
                            .output(tempCroppedPath)
                            .on('end', () => resolve())
                            .on('error', (err) => reject(err))
                            .run();
                    });
                    
                    // تحديد مدة الفيديو إلى 6 ثوانٍ إذا كانت أطول من ذلك
                    let processedPath = tempCroppedPath;
                    if (duration > 6) {
                        console.log("Video is longer than 6 seconds, trimming...");
                        await new Promise((resolve, reject) => {
                            ffmpeg(tempCroppedPath)
                                .setDuration(6)
                                .output(tempDurationPath)
                                .on('end', () => resolve())
                                .on('error', (err) => reject(err))
                                .run();
                        });
                        processedPath = tempDurationPath;
                    }
                    console.log("Optimizing video size...");
                    await new Promise((resolve, reject) => {
                        ffmpeg(processedPath)
                            .videoCodec('libx264')
                            .outputOptions([
                                '-pix_fmt yuv420p',
                                '-crf 30', // جودة الضغط (أعلى قيمة = ضغط أكبر)
                                '-preset ultrafast' // سرعة المعالجة (أسرع ولكن حجم أكبر قليلاً)
                            ])
                            .noAudio() // إزالة الصوت لتقليل الحجم
                            .output(tempOutputPath)
                            .on('end', () => resolve())
                            .on('error', (err) => reject(err))
                            .run();
                    });
                    processedBuffer = fs.readFileSync(tempOutputPath);
                    const finalSizeMB = processedBuffer.length / (1024 * 1024);
                    console.log(`Processed file size: ${finalSizeMB.toFixed(2)} MB`);
                    if (finalSizeMB > MAX_FILE_SIZE_MB) {
                        console.log("File still too large, applying extreme compression...");
                        const extremeOutputPath = path.join(tempDir, `extreme_${Date.now()}.${mediaType === 'gif' ? 'gif' : 'mp4'}`);
                        
                        await new Promise((resolve, reject) => {
                            ffmpeg(tempOutputPath)
                                .videoCodec('libx264')
                                .size('128x128') // تقليل الأبعاد بشكل كبير
                                .outputOptions([
                                    '-pix_fmt yuv420p',
                                    '-crf 40', // ضغط عالي جدًا
                                    '-preset ultrafast',
                                    '-an' // إزالة الصوت
                                ])
                                .output(extremeOutputPath)
                                .on('end', () => resolve())
                                .on('error', (err) => reject(err))
                                .run();
                        });
                        
                        processedBuffer = fs.readFileSync(extremeOutputPath);
                        console.log(`Extreme compression file size: ${(processedBuffer.length / (1024 * 1024)).toFixed(2)} MB`);
                        
                        fs.unlink(extremeOutputPath, (err) => {
                            if (err) console.error("Error deleting extreme output file:", err);
                        });
                    }
                    const filesToDelete = [tempInputPath, tempCroppedPath, tempOutputPath];
                    if (duration > 6) filesToDelete.push(tempDurationPath);
                    
                    filesToDelete.forEach(file => {
                        fs.unlink(file, (err) => {
                            if (err) console.error(`Error deleting temp file ${file}:`, err);
                        });
                    });
                    
                } catch (ffmpegError) {
                    console.error("Error processing video/gif:", ffmpegError);
                    processedBuffer = buffer;
                }
            }
            const isAnimated = mediaType === 'video' || mediaType === 'gif';
            console.log("Creating sticker...");
            const sticker = new Sticker(processedBuffer, {
                pack: textuals.stikerMaker.right,
                author: textuals.stikerMaker.right,
                type: StickerTypes.FULL,
                categories: ['🤩', '🎉'],
                quality: isAnimated ? 20 : 40, // تقليل الجودة لتقليل الحجم
                background: 'transparent',
                crop: false, // تعطيل القص التلقائي لأننا قمنا بالمعالجة يدويًا
                animated: isAnimated
            });
            
            const stickerBuffer = await sticker.toBuffer();
            await sock.sendMessage(msg.key.remoteJid, {
                sticker: stickerBuffer
            });
        } catch (error) {
            console.error("Error in sticker creation:", error);
        }
    }
};