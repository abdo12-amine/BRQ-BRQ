const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
module.exports = {
       name : commands.mentionsWord.Plug,
       description: commands.mentionsWord.desc,
       async execute(sock,msg,args){
              if(msg.key.remoteJid.endsWith("@g.us")){
                     try {
                            const metadata = await sock.groupMetadata(msg.key.remoteJid);
                            const MontionnedMembers = metadata.participants.map((p) => p.id);
                            await sock.sendMessage(msg.key.remoteJid,{
                                   text:textuals.mentionsWord.text,
                                   mentions:MontionnedMembers,
                            },
                            {quoted:msg}
                     );
                     console.log(MontionnedMembers)
                     } catch (error) {
                     console.log(error) 
                     }
                     
              };

       }
};