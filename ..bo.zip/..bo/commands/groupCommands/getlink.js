const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");

module.exports = {
       name : commands.getlink.plug,
       description: commands.getlink.desc,
       async execute(sock,msg,args){
              if(msg.key.remoteJid.endsWith("@g.us")){
                     try {
                     const inviteCode = await sock.groupInviteCode(msg.key.remoteJid);
                     await sock.sendMessage(msg.key.remoteJid, {
                            text: `https://chat.whatsapp.com/${inviteCode}`,
                        });
                     } catch (error) {
                     console.log(error);
                     }
                     
              };

       }
};