const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
module.exports = {
       name : commands.promote.plug,
       description: commands.promote.desc,
       async execute(sock,msg,args,MyJid){
              if(msg.key.remoteJid.endsWith("@g.us")){
                     try {
                            const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
                            const mentionedJids = contextInfo?.mentionedJid || [];
                            if (mentionedJids.length > 0) {
                                 if (mentionedJids.includes(MyJid.id) || mentionedJids.includes(MyJid.lid)) {
                                        return;
                                  }
                                for (const oneMention of mentionedJids) {
                                    await sock.sendMessage(msg.key.remoteJid, {
                                        react: {
                                            text: "🔼",
                                            key: msg.key
                                        }
                                    });
                                    await sock.groupParticipantsUpdate(msg.key.remoteJid, [oneMention], "promote");
                                }
                            } else if (contextInfo?.participant) {
                                // Handle quoted message case (when no mentions)
                                const userJid = contextInfo.participant;
                                if (userJid === MyJid.id && userJid === MyJid.lid) {
                                    return;
                                }
                                await sock.sendMessage(msg.key.remoteJid, {
                                    react: {
                                        text: "🔼",
                                        key: msg.key
                                    }
                                });
                                await sock.groupParticipantsUpdate(msg.key.remoteJid, [userJid], "promote");
                            }
                        } catch (error) {
                            console.log(error);
                        }
                     
              };

       }
};