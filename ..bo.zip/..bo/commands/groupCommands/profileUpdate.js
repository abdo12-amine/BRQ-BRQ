const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");
const { downloadMediaMessage } = require("@whiskeysockets/baileys");
module.exports = {
       name : commands.profileUpdate.plug,
       description: commands.profileUpdate.desc,
       async execute(sock, msg, args) {
              if(msg.key.remoteJid.endsWith("@g.us")) {
                     try {
                            if (!msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) return;  
                            const quotedMsg = msg.message.extendedTextMessage.contextInfo;
                            let type = Object.keys(quotedMsg.quotedMessage)[0];
                            if (type !== 'imageMessage') return;
                            try {
                                   const logger = {
                                          info: (...args) => console.log(...args),
                                          debug: (...args) => console.debug(...args),
                                          warn: (...args) => console.warn(...args),
                                          error: (...args) => console.error(...args)
                                   };
                                   
                                   const message = {
                                        key: {
                                            remoteJid: msg.key.remoteJid,
                                            id: quotedMsg.stanzaId
                                        },
                                        message: quotedMsg.quotedMessage
                                   };
                                   const stream = await downloadMediaMessage(
                                          message,
                                          'buffer',
                                          {},
                                          { 
                                              logger,
                                              reuploadRequest: sock.updateMediaMessage 
                                          }
                                   );
                                   await sock.updateProfilePicture(msg.key.remoteJid, stream);
                            } catch (error) {
                                   console.log(error)
                            }
                     } catch (error) {
                            console.log(error);
                     }
              }
       }
};