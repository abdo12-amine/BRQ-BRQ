const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');

module.exports = {
  command: ['تست'],
  description: 'اختبار عمل البوت مع صورة ورابط',
  category: 'tools',
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const text = '𝐸𝑉𝐸𝐿𝑌𝑁 𝐵𝑂𝑇 𝐼𝑆 𝑊𝑂𝑅𝐾𝐼𝑁𝐺 🎀';
    const thumbnailUrl = 'https://files.catbox.moe/1cj2uy.jpg';
    const sourceUrl = 'https://whatsapp.com/channel/0029Vb8bVO9CnA7tPot3RO3m';

    const message = generateWAMessageFromContent(jid, {
      extendedTextMessage: {
        text: text,
        contextInfo: {
          externalAdReply: {
            title: '𝑇𝐸𝑆𝑇🍡',
            body: '𝐸𝑉𝐸𝐿𝑌𝑁 𝐵𝑂𝑇🍥',
            thumbnailUrl: thumbnailUrl,
            sourceUrl: sourceUrl,
            mediaType: 1,
            renderLargerThumbnail: true,
            thumbnail: { url: thumbnailUrl }
          }
        }
      }
    }, { quoted: msg });

    await sock.relayMessage(jid, message.message, { messageId: message.key.id });
  }
};