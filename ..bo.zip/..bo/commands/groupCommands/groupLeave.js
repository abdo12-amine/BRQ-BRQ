const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
module.exports = {
       name : commands.leaveGb.plug,
       description: commands.leaveGb.desc,
       async execute(sock,msg,args,MyJid){
        if(!msg.key.remoteJid.endsWith("@g.us"))return;
        try {
            if(!msg.key.fromMe)return;
            await sock.groupLeave(msg.key.remoteJid);
        } catch (error) {
            console.log(error) 
        }       
              }
       }
