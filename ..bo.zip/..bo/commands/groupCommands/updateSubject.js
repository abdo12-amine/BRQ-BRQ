const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
module.exports = {
       name : commands.updateSubject.Plug,
       description: commands.updateSubject.desc,

       async execute(sock,msg,args){
              if(msg.key.remoteJid.endsWith("@g.us")){
                     try {
                            if(args.length === 0 && args.length < 70)return;
                            const NewSubject = args.join(" ");
                            await sock.groupUpdateSubject(msg.key.remoteJid,NewSubject);
                     } catch (error) {
                     console.log(error);
                     }
              };
       }
};