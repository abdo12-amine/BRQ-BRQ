const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
const fs = require("fs")
module.exports = {
       name : commands.demoteall.plug,
       description: commands.demoteall.desc,
       async execute(sock,msg,args,MyJid){
              if(msg.key.remoteJid.endsWith("@g.us")){
                     try {
                        const groupMetadata = await sock.groupMetadata(msg.key.remoteJid);
                        const groupId = msg.key.remoteJid;
                        const membersToDemote = groupMetadata.participants
                        .filter((p) =>p.admin &&  p.id !== MyJid.id && p.id !==MyJid.lid )
                        .map((p) => p.id);
                        await sock.groupParticipantsUpdate(groupId, membersToDemote, "demote");
                        await sock.sendMessage(msg.key.remoteJid,{react:{text:"✅",key:msg.key}});
                     } catch (error) {
                     console.log(error)
                     } 
              };

       }
};
                     
     
                       