const path = require('path');
const fs = require('fs').promises;
const paths = require('../../resources/paths');
const textuals = require('../../resources/textuals');
const commands = require('../../resources/commands');

function generateCustomId(existingIds) {
    const chars = '0123456789XYZ';
    let customId;
    do {
        customId = '';
        for (let i = 0; i < 3; i++) {
            const randomIndex = Math.floor(Math.random() * chars.length);
            customId += chars[randomIndex];
        }
    } while (existingIds.includes(customId));
    return customId;
};

async function saveFunction(targetSock,msg,sock) {
    try {
        let existingIds = [];
        const filePath = path.join("resources/dataFiles", 'ControleFile.json');
        try {
            const fileData = await fs.readFile(filePath,'utf8');
            const groups = JSON.parse(fileData);
            existingIds = groups.map(group => group.customId);
        } catch (error) {
            if (error.code !== 'ENOENT') throw error; 
        }
        const groups = await targetSock.groupFetchAllParticipating();
        const groupList = Object.entries(groups).map(([id, group]) => ({
            jid: id,
            name: group.subject || 'unknown',
        }));
    
        const updatedGroups = groupList.map(group => {
                    const customId = generateCustomId(existingIds);
                    existingIds.push(customId);
                    return {
                        jid: group.jid,
                        name: group.name,
                        customId,
                    };
                });
                await fs.writeFile("resources/dataFiles/ControleFile.json", JSON.stringify(updatedGroups, null, 2));
    
                // Send success reaction
                await sock.sendMessage(msg.key.remoteJid, {
                    react: {
                        text: '✅',
                        key: msg.key,
                    },
                });
    } catch (error) {
        console.error(error);
    }
   

}

module.exports = {
    name: commands.saveGroups.plug,
    description: commands.saveGroups.desc,
    async execute(sock, msg, args, MyJid, sender, activeSessions) {
       if(!args || args.length === 0){
        const targetSock = sock;
        await saveFunction(targetSock,msg,sock);
        return;
       };

       const sessionName = args[0].toLowerCase();

       const targetSock = activeSessions[sessionName];
       if(!targetSock)return await sock.sendMessage(msg.key.remoteJid,{react:{
        text:"⚠️",
        key:msg.key
       }})
       console.log(activeSessions)
       await saveFunction(targetSock,msg,sock);

    },
};