const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
const path = require('path');
const fs = require('fs').promises;
module.exports = {
       name : commands.allGroupPreview.plug,
       description: commands.allGroupPreview.desc,
       async execute(sock,msg,args){
              try {
                const filePath = path.join("resources/dataFiles", 'ControleFile.json');
                let groups = [];
                try {
                     const fileData = await fs.readFile(filePath, 'utf8');
                     groups = JSON.parse(fileData);
                } catch (error) {
                    if(error.code === 'ENOENT') {
                        await sock.sendMessage(msg.key.remoteJid, {
                            react: {
                                text: "⚠️",
                                key: msg.key
                            }
                        });
                        return;
                    }
                };
                if (groups.length === 0) {
                  await sock.sendMessage(msg.key.remoteJid, {text:"𝗡𝗼 𝗴𝗿𝗼𝘂𝗽𝘀 𝘀𝗮𝘃𝗲𝗱 !"});
                    return;
                }
                const groupList = groups.map((group)=> {
         return `
┃ *𝑵𝒂𝒎𝒆:* ${group.name}
┃ *𝑮𝒓𝒐𝒖𝒑J𝒊𝒅:* ${group.jid.replace("@g.us", "")}
┃ *𝑪𝒐𝒔𝒕𝒖𝒎 𝑰𝒅:* ${group.customId}
┗━━━━━━━━ `}).join("");




                
                const message = `┏━━━━━━━ *${textuals.nameBot}* ━━━━━━━${groupList}`;
                await sock.sendMessage(msg.key.remoteJid, {
                    text: message
                
                });
               
              } catch (error) {
                console.error(error)
              }
                    
              }
       }