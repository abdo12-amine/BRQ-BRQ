const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");

module.exports = {
    name: "ds",
    description: commands.getLinkedDevices.desc,
    async execute(sock, msg, args, MyJid) {
        try {
          console.log(sock)
        } catch (error) {
            console.error("❌ Error in 'ds' command:", error);
        }
    }
};
