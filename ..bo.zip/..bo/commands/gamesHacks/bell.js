const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");

let tracking = false;
let UserToTrack = null;
let groupId = null;

let listenerAttached = false;

module.exports = {
    name: "جرس",
    description: commands,
    async execute(sock, msg, args) {
        if (!msg.key.remoteJid.endsWith("@g.us")) return;
        groupId = msg.key.remoteJid;
        if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
            UserToTrack = msg.message.extendedTextMessage.contextInfo.participant;
            tracking = true;
            if (!listenerAttached) {
                sock.ev.on("messages.upsert", async (msm) => {
                    const sms = msm.messages[0];
                    if (!sms.message || sms.key.remoteJid !== groupId) return;
                    if (sms.key.participant !== UserToTrack) return;

                    if (tracking && sms.message.imageMessage) {
                        await sock.sendMessage(groupId, { text: "🛎️" });
                    }
                });
                listenerAttached = true;
            }
        } else {
            tracking = false;
            UserToTrack = null;
        }
    }
}
