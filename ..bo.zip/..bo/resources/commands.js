


const commands = {
takeover:{
       plug:".take",
       desc:"تغيير معلومات المجموعة"
},
getlink:{
       plug:".link",
       desc:"الحصول على رابط المجموعة"
},
mentionsWord:{
       Plug:".custom",
       desc:"منشن بالاستخدام كلمة ثابثة",
},
testBot:{
       plug:".test",
       desc:"اختبار اشتغال البوت",
},
promote:{
       plug:".promote",
       desc:"ترقية عضو الى رتبة مشرف"
},
demote:{
       plug:".demote",
       desc:"سحب اشراف عضو",
},
kickOne:{
       plug:".kick",
       desc:"طرد عضو"
},
customMention:{
       plug:".mention",
       desc:"منشن بالكلام جانب الأمر",
},
killGroup:{
       plug:".kill",
       desc:"طرد كل أعضاء المجموعة",
},
groupChecker:{
       plug:".info",
       desc:"الحصول على معلومات المجموعة من خلال الرابط"
},
block:{
       plug:".block",
       desc:"فك حظر عضو",
},
unblock:{
       plug:".unblock",
       desc:"فك حظر من العضو "
},
listOfBlock:{
       plug:".blocked",
       desc:"قائمة الناس المحظورين"
},
updateSubject:{
       Plug:".subject",
       desc:"تحديت اسم المجموعة"
},
profileUpdate:{
       plug:".setprofile",
       desc:"تغيير صورة المجموعة",
},
stikerMaker:{
       plug:".tosticker",
       desc:"تحويل الصورة الى ستكر ",
},
getProfileImg:{
       plug:".getprofile",
       desc:"جلب صورة البورفايل  للمستخدم"
},
personalProfileImageUpdate:{
       plug:".setpic",
       desc:"تغيير الصورة الشخصية"
}
,addToListCustom:{
       plug:".contact",
       desc:"اضافة الارسال باللقب"
},
costumSend:{
       plug:".sendto",
       desc:"ارسال رسالة الى احد الارقام"
},
costumAdd:{
       plug:".add",
       desc:"اضافة رقم الى مجموعة"
},
poll:{
       plug:".poll",
       desc:"انشاء تصويت"
},
generateSticker:{
       plug:".sticker",
       desc:"تحويل النص الى ستكر",
},
stickerHelper:{
       plug:".stickerhelp",
       desc:"مساعدة في استخدام الامر",
},
antiViewOnce: {
       plug: ".view",
       desc: "عرض الرسائل ذات المشاهدة الواحدة" 
},
getKickedCount: {
       plug: ".count_k",
       desc: "الحصول على عدد الأعضاء المطرودين" 
}, 
unlockGb: {
       plug: ".unlock",
       desc: "فتح المجموعة" 
},
lockGb: {
       plug: ".lock",
       desc: "قفل المجموعة" 
},
unlockGb: {
       plug: ".unlock",
       desc: "فتح المجموعة" 
},
destory:{
       plug:".force",
       desc:"الزرف السريع للمجموعة"
},
demoteall:{
       plug:".demote_a",
       desc:"سحب الاشراف من الجميع"
}, 
commList:{
       plug:".commands",
       desc:"عرض الاوامر المتاحة"
},
getAdmin:{
       plug:".admin",
       desc:"الحصول على ادمن المجموعة"
},
Xmode:{
       plug:".xmode",
       desc:"سحب الاشراف التلقائي "
},
addGbToSafeList:{
       plug:".safe",
       desc:"اضافة المجموعة الى قائمة الحماية"
},
groupsList:{
       plug:".groups",
       desc:"قائمة المجموعات التي يتواجد فيها البوت"
},
leaveGb:{
       plug:".leave",
       desc:"مغادرة المجموعة"
},
monite:{
       plug:".monite",
       desc:"تفعيل امر المراقبة"
},
autoBlock:{
       plug:".autoblock",
       desc:"تفعيل حظر تلقائي"
},
newSession:{
       plug:".new",
       desc:"بدأ جلسة جديدة"
},
removeSession:{
       plug:".remove",
       desc:"حذف الجلسة معينة"
},
runSession:{
       plug:".run",
       desc:"تشغيل جلسة معينة"
},
stopSession:{
       plug:".stop",
       desc:"ايقاف جلسة معينة"
},
listSession:{
       plug:".sessions",
       desc:"قائمة الجلسات المتاحة"
},
cancelSession:{
       plug:".cancel",
       desc:"الغاء الطلب الحالي لانشاء الجلسة"
},
previewOnceGroup:{
       plug:".preview",
       desc:"عرض معلومات المجموعة من خلال الكود"
},
allGroupPreview:{
       plug:".previewall",
       desc:"عرض جميع المجموعات المتاحة"
},
saveGroups:{
       plug:".save",
       desc:"حفظ مجموعات بايدي مميز"
},
getLinkedDevices:{
       plug:".linked",
       desc:"الحصول على عدد الاجهزة المرتبطة ب رقم معين"
},
antiCall:{
       plug:".anticall",
       desc:"تفعيل وضع منع المكالمات"
},
sessionGetAdmin:{
       plug:".pro",
       desc:"اخد ادمنات الجلسات"
},
getAllGbAdmin:{
       plug:".alladmin",
       desc:"اخد ادمنات جميع المجموعات"
},
song: {
    plug: ".Tik",
    desc: "تحميل أغنية MP3 من تيك توك عبر الاسم"
  },

};
module.exports = commands;