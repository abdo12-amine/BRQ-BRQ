function react(sock, jid, key, emoji) {
    return sock.sendMessage(jid, {
      react: {
        text: emoji,
        key,
      },
    });
  }
  
  module.exports = react;
  