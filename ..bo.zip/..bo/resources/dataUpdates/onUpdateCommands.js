const fs = require('fs');
const path = require('path');
const commandsPath = path.join(__dirname, '../../commands');
function setupHotReload(commandsMap) {
    fs.watch(commandsPath, { recursive: true }, (eventType, filename) => {
        if (filename.endsWith('.js')) {
            const filePath = path.join(commandsPath, filename);
            if (eventType === 'rename') {
                if (fs.existsSync(filePath)) {
                    try {
                        delete require.cache[require.resolve(filePath)];
                        const updatedCommand = require(filePath);

                        if (updatedCommand.name) {
                            commandsMap.set(updatedCommand.name, updatedCommand);
                        }
                    } catch (error) {
                    }
                } else {
                    const commandName = filename.replace('.js', '');
                    commandsMap.delete(commandName);
                }
            } else if (eventType === 'change') {
                try {
                    delete require.cache[require.resolve(filePath)];
                    const updatedCommand = require(filePath);

                    if (updatedCommand.name) {
                        commandsMap.set(updatedCommand.name, updatedCommand);
                    }
                } catch (error) {
                    console.error(`[HOT RELOAD] Error reloading ${filename}:`, error);
                }
            }
        }
    });

    console.log('Real-time command reloading enabled ');
}
module.exports = { setupHotReload };
