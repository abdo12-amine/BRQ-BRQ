const commmnds = require("../resources/commands");
module.exports = {
  name: commmnds.listSession.plug,
  execute: async (
    sock,
    msg,
    args,
    MyJid,
    sender,
    activeSessions,
    sessionsToNotReconnect,
    startBotInstance,
    pendingSessions,
    isSessionFolderEmpty
  ) => {
    const sessionName = sock.sessionName;
    const sessions = Object.keys(activeSessions);

    if (sessions.length === 0) {
      await sock.sendMessage(msg.key.remoteJid, { text: "𝗡𝗼 𝘀𝗲𝘀𝘀𝗶𝗼𝗻 𝗮𝗰𝘁𝗶𝘃𝗲𝗱 :" });
      return;
    }

    let message = "Active sessions:\n";
    sessions.forEach((session, index) => {
      message += `${index + 1}. ${session}${session === sessionName ? " (𝒄𝒖𝒓𝒓𝒆𝒏𝒕 𝒔𝒆𝒔𝒔𝒊𝒐𝒏)" : ""}\n`;
    });

    await sock.sendMessage(msg.key.remoteJid, { text: message });
  },
};