const commmnds = require("../resources/commands");
const fs = require("fs");
const path = require("path");
const commands = require("../resources/commands");

const SESSIONS_DIR = "sessions";

module.exports = {
  name: commands.removeSession.plug,
  execute: async (
    sock,
    msg,
    args,
    MyJid,
    sender,
    activeSessions,
    sessionsToNotReconnect,
    startBotInstance,
    pendingSessions,
    isSessionFolderEmpty
  ) => {
    const sessionName = sock.sessionName;

    if (args.length === 0) {
      await sock.sendMessage(msg.key.remoteJid, {
        text: "Please provide a session name to remove, example: .remove session2",
      });
      return;
    }

    const removeSessionName = args[0];
    const sessionFolder = path.join(SESSIONS_DIR, removeSessionName);

    if (removeSessionName === sessionName) {
      await sock.sendMessage(msg.key.remoteJid, {
        text: `𝗖𝗮𝗻𝗻𝗼𝘁 𝗿𝗲𝗺𝗼𝘃𝗲 𝘁𝗵𝗲 𝗰𝘂𝗿𝗿𝗲𝗻𝘁 𝘀𝗲𝘀𝘀𝗶𝗼𝗻.`,
      });
      return;
    }



    try {
      if (activeSessions[removeSessionName]) {
        sessionsToNotReconnect.add(removeSessionName);
        activeSessions[removeSessionName].end();
        delete activeSessions[removeSessionName];
      }

      if (fs.existsSync(sessionFolder)) {
        fs.rmSync(sessionFolder, { recursive: true, force: true });
        await sock.sendMessage(msg.key.remoteJid, { text: `𝗦𝗲𝘀𝘀𝗶𝗼𝗻 𝗿𝗲𝗺𝗼𝘃𝗲𝗱 : '${removeSessionName}` });
      } else {
        await sock.sendMessage(msg.key.remoteJid, { text: `𝗦𝗲𝘀𝘀𝗶𝗼𝗻 𝗻𝗼𝘁 𝗳𝗼𝘂𝗻𝗱 : ${removeSessionName}` });
      }
    } catch (error) {
      console.error(`[${sessionName}] Error removing session '${removeSessionName}':`, error);
    }
  },
};