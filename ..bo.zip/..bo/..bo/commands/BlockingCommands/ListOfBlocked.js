const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
module.exports = {
       name : commands.listOfBlock.plug,
       description: commands.listOfBlock.desc,
       async execute(sock,msg,args){
                     try {
                     const listOfBlock = await sock.fetchBlocklist();
                     if(listOfBlock.length === 0)return;
                     const formattedText =  listOfBlock.map((num, index) => `${index + 1}. +${num.replace("@s.whatsapp.net", "")}`)
                     .join("\n");
                     await sock.sendMessage(msg.key.remoteJid,
                            {text:formattedText},
                            {quoted:msg}     
                     );
                     } catch (error) {
                     console.log(error) 
                     }

       }
};