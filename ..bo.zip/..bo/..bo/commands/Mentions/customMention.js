    const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");

module.exports = {
    name: commands.customMention.plug,
    description: commands.customMention.desc,
    async execute(sock, msg, args) {
        // Check if the message is in a group
        if (msg.key.remoteJid.endsWith("@g.us")) {
            try {
                if (args.length === 0) {
                    return;
                }
                const metadata = await sock.groupMetadata(msg.key.remoteJid);
                const mentionedMembers = metadata.participants.map((p) => p.id);
                const messageText = args.join(" ");
                await sock.sendMessage(msg.key.remoteJid, { 
                    delete: msg.key 
                });
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: messageText, 
                    mentions: mentionedMembers 
                });
                
            } catch (error) {
                console.log(error);
            }
        } 
    }
};