const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");

module.exports = {
  name:"gf",
  description: commands.mentionsWord.desc,

  async execute(sock, msg, args) {
    if (msg.key.remoteJid.endsWith("@g.us")) {
      try {
        const metadata = await sock.groupMetadata(msg.key.remoteJid);
        const mentionedMembers = metadata.participants.map(p => p.id);

        await sock.sendMessage(msg.key.remoteJid, {
          text: mentionedMembers.map(id => `@${id.split("@")[0]}`).join(" "),
          mentions: mentionedMembers
        }, { quoted: msg });

        console.log(mentionedMembers);
      } catch (error) {
        console.error("❌ Error mentioning members:", error);
      }
    }
  }
};
