const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");

async function lockGb(sock,msg,MyJid){
       const metadata = await sock.groupMetadata(msg.key.remoteJid);
       const isLid = metadata.participants.find((participant) => participant.id === MyJid.lid);
       if(!isLid){
           await sock.sendMessage(msg.key.remoteJid, {
                            react: {
                                text: "🔒",
                                key: msg.key,
                            }
                        });   
       }
        await sock.groupSettingUpdate(msg.key.remoteJid, "announcement");
}
module.exports = {
       name : commands.lockGb.plug,
       description: commands.lockGb.desc,
       async execute(sock,msg,args,MyJid){
              if(msg.key.remoteJid.endsWith("@g.us")){
                     try {
                             await lockGb(sock,msg,MyJid);
                        await sock.groupSettingUpdate(msg.key.remoteJid, "announcement");
                     } catch (error) {
                     console.log(error) 
                     }
                     
              };

       }
};