const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
const updateKickedCount = require("../../resources/dataUpdates/kickUpdates");
module.exports = {
       name : commands.kickOne.plug,
       description: commands.kickOne.desc,
       async execute(sock,msg,args,MyJid){
              if(msg.key.remoteJid.endsWith("@g.us")){
                     try {
                            const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
                            const mentionedJids = contextInfo?.mentionedJid || [];
                            let NumOfKicked = 0 ;
                            
                            if (mentionedJids.length > 0) {
                                   if (mentionedJids.includes(MyJid)) {
                                          return;
                                    }
                             
                                    await sock.sendMessage(msg.key.remoteJid, {
                                        react: {
                                            text: "🗑️",
                                            key: msg.key
                                        }
                                    });
                                    await sock.groupParticipantsUpdate(msg.key.remoteJid, mentionedJids , "remove");
                                    NumOfKicked = mentionedJids.length
                                    await updateKickedCount(NumOfKicked);

                                
                            } else if (contextInfo?.participant) {
                                const userJid = contextInfo.participant;
                                   if (userJid === MyJid.id || userJid === MyJid.lid) {
                                          return;
                                   }
                                await sock.sendMessage(msg.key.remoteJid, {
                                    react: {
                                        text: "🗑️",
                                        key: msg.key
                                    }
                                });
                                await sock.groupParticipantsUpdate(msg.key.remoteJid, [userJid], "remove");
                                NumOfKicked = userJid.length
                                await updateKickedCount(NumOfKicked);
                            }
                        } catch (error) {
                            console.log(error);
                        }
                     
              };

       }
};