const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");
const fs = require('fs').promises;
const path = require('path');

module.exports = {
    name: commands.poll.plug,
    description:commands.poll.desc,
    async execute(sock, msg, args) {
        const isGroup = msg.key.remoteJid.endsWith('@g.us');
        if (!isGroup) {
            return;
        }
        const fullText = args.join(' ');
        const questionMatch = fullText.match(/\[(.*?)\]/);
        if (!questionMatch) {
            return;
        }
        const question = questionMatch[1];
        const optionsMatches = fullText.slice(fullText.indexOf(']') + 1).match(/\[(.*?)\]/g);
        if (!optionsMatches || optionsMatches.length < 2) {
            return;
        }
        const options = optionsMatches.map(opt => opt.slice(1, -1));
        const maxOptions = 12;
        if (options.length > maxOptions) {
            options.splice(maxOptions);
        }

        try {
            const pollMessage = {
                poll: {
                    name: question,
                    values: options,
                    selectableCount: 1
                }
            };
            await sock.sendMessage(msg.key.remoteJid, pollMessage);
        } catch (error) {
            console.error(error);
        }
    }
};
