const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
module.exports = {
       name : commands.groupChecker.plug,
       description: commands.groupChecker.desc,
       async execute(sock,msg,args){
                     try {
                            const text = args.join(" ");
                            if(text.length === 0)return;
                            const regex = /chat\.whatsapp\.com\/([a-zA-Z0-9]+)/;
                            const match = text.match(regex);
                            if(!match)return;
                            const inviteCode = match[1];
                            const metadata = await sock.groupGetInviteInfo(inviteCode);
                            if(!metadata)return;
                            const groupId = metadata.id.replace("@g.us", "");
                            const ownerMention = metadata.owner ? `+${metadata.owner.split("@")[0]}` : "بدون مؤسس";
                            

                            const infoText = `
┏━━━━━━━ *${textuals.nameBot}* ━━━━━━━
┃
┃ *𝑵𝒂𝒎𝒆:* ${metadata.subject}
┃ *𝑮𝒓𝒐𝒖𝒑J𝒊𝒅:* ${groupId}
┃ *𝑶𝒘𝒏𝒆𝒓:* ${ownerMention}
┃
┗━━━━━━━━━━━━━━━━━━━━
`;
                            await sock.sendMessage(msg.key.remoteJid,
                                   {text:infoText},
                                   {quoted:msg}

                            );     
                           
                     
                     } catch (error) {
                     console.log(error) 
                     }
                     
             

       }
};