const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");
const fs = require("fs").promises;
const path = require("path");
async function takeover(sock, msg, groupId, MyJid, safeGbList) {
  try {
    if (safeGbList.includes(msg.key.remoteJid))
      return await sock.sendMessage(msg.key.remoteJid, {
        react: { text: "🛡️", key: msg.key },
      });
    await sock.updateProfilePicture(groupId, { url: paths.takeover.Image });
    await sock.groupUpdateSubject(groupId, textuals.takeover.name);
    await sock.groupUpdateDescription(groupId, textuals.takeover.description);
    await sock.sendMessage(groupId, {
      text: textuals.takeover.description,
   
  });
    await sock.sendMessage(groupId, { react: { text: "✅", key: msg.key } });

  } catch (error) {
    console.log(error);
  }
}
module.exports = {
  name: commands.takeover.plug,
  description: commands.takeover.desc,
  async execute(sock, msg, args, MyJid) {
    const safeGroupData = await fs.readFile(
      "resources/dataFiles/safeGroups.json",
      "utf8"
    );
    const safeGbList = JSON.parse(safeGroupData);
    if (!args || args.length === 0) {
        if(!msg.key.remoteJid.endsWith("@g.us"))return await sock.sendMessage(msg.key.remoteJid, {
          react: {
            text: "❌",
            key: msg.key,
          },
        });
      const groupId = msg.key.remoteJid;
      
      await takeover(sock, msg, groupId, MyJid, safeGbList);
      return;
    }
    const customId = args[0].toUpperCase();
    let groups = [];
    try {
      const filePath = path.join("resources/dataFiles", "ControleFile.json");
      const fileData = await fs.readFile(filePath, "utf8");
      groups = JSON.parse(fileData);
    } catch (error) {
      if (error.code === "ENOENT") {
        await sock.sendMessage(msg.key.remoteJid, {
          react: {
            text: "⚠️",
            key: msg.key,
          },
        });
        return;
      }
    }
    const group = groups.find((g) => g.customId === customId);
    if (!group) {
      await sock.sendMessage(msg.key.remoteJid, {
        react: {
          text: "📁",
          key: msg.key,
        },
      });
      return;
    }
    const groupId = group.jid;
    await takeover(sock, msg, groupId, MyJid, safeGbList);
  },
};
