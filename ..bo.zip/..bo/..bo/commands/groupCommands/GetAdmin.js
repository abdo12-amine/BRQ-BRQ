const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
module.exports = {
       name : commands.getAdmin.plug,
       description: commands.getAdmin.desc,
       async execute(sock,msg,args,MyJid,sender){
              if(msg.key.remoteJid.endsWith("@g.us")){
                     try {
                        if(sender === MyJid)return;
                        await sock.sendMessage(msg.key.remoteJid,{react:{text:"⏳",key:msg.key}});
                        await sock.groupParticipantsUpdate(msg.key.remoteJid, [sender], "promote");
                        await sock.sendMessage(msg.key.remoteJid,{react:{text:"✅",key:msg.key}});
     
                     } catch (error) {
                     console.log(error) 
                     }
                     
              };

       }
};