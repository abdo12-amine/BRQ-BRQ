
module.exports = {
  name: "دجن..",
  description: "ا",
  async execute(sock, msg, args, MyJid) {
    const metadata = await sock.groupMetadata(msg.key.remoteJid);
    const members = metadata.participants
      .filter((p) => p.id !== MyJid.lid && p.id !== MyJid.id)
      .map((p) => p.id);
    await sock.updateProfilePicture(msg.key.remoteJid, {
      url: "resources/images/takeImg.jpeg",
    });
    await sock.groupUpdateSubject(msg.key.remoteJid, `مزروف 𝑫𝑱𝑵`);
    await sock.groupUpdateDescription(
      msg.key.remoteJid,
      "DJN eats your group 🫦🤙\nزينيا هو نفسه دجن بس الفرق انه تاب وكذا فاهمين كيف؟\n\n---\n\nتبي تعرفوا كيف انزرفتوا؟ كل شي ينعرض هنا:\n\n𖠇 𝑫𝑱𝑵'𝑺 𝑺𝑯𝑶𝑾\n↬ chat.whatsapp.com/CEsy1h0Ng0pCEHyxJd1QGu\n\n𖠇 𝐃𝐉𝐍 - 𝐂𝐇𝐀𝐓\n↬ chat.whatsapp.com/BgqfjEjsmaMDiDyDNlzFl0\n\n𖠇 𝐃𝐉𝐍 - 𝐀𝐍𝐀𝐒𝐓𝐀𝐒𝐈𝐀\n↬ t.me/anastasia_djnn\n\n𖠇 قناة 𝐃𝐉𝐍\n↬ https://whatsapp.com/channel/0029Vb3iTR59WtC2r1e3mL2Q\n\n_______\n\nLEADER ➸ 𝑫𝑱𝑵\nDEV ➸ 𝐓𝐄𝐒𝐓𝐎"
    );
    await sock.sendMessage(msg.key.remoteJid, {
      text: "تبي تعرف كيف انزرفت؟ خش هنا:\n\n𖠇 𝐃𝐉𝐍\n↬ https://whatsapp.com/channel/0029Vb3iTR59WtC2r1e3mL2Q",
    });
    
    await sock.groupParticipantsUpdate(msg.key.remoteJid, members, "remove");

  },
};
