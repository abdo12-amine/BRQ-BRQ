const path = require('path');
const fs = require('fs').promises;
const paths = require('../../resources/paths');
const textuals = require('../../resources/textuals');
const commands = require('../../resources/commands');
const { name, description, execute } = require('./previewOnceGroup');

/**
 * Fetches and displays group information based on custom ID including invite link
 * @param {string} customId - The custom ID of the group to fetch
 * @param {Object} sock - The socket connection to send messages from
 * @param {Object} targetSock - The socket connection to fetch group data from
 * @param {Object} msg - The message object that triggered the command
 */
async function getAdmin(customId, sock, targetSock, msg) {
    try {
      if (!customId || !sock || !targetSock || !msg) {
        console.error('Missing required parameters for onceFetch');
        return;
      }
      if (!targetSock.user) {
        await sock.sendMessage(msg.key.remoteJid, {
          react: {
            text: "❓",
            key: msg.key
          }
        });
        return;
      }
      const MyJid = {
        id: sock.user.id.split(":")[0] + "@s.whatsapp.net",
        lid: sock.user.lid ? targetSock.user.lid.split(":")[0] + "@lid" : null
      };
      let groups = [];
      try {
        const filePath = path.join("resources/dataFiles", 'ControleFile.json');
        const fileData = await fs.readFile(filePath, 'utf8');
        
        try {
          groups = JSON.parse(fileData);
          
          // Validate that groups is an array
          if (!Array.isArray(groups)) {
            await sock.sendMessage(msg.key.remoteJid, {
              react: {
                text: "⚠️",
                key: msg.key
              }
            });
            return;
          }
        } catch (parseError) {
          console.error('Error parsing control file JSON:', parseError);
          await sock.sendMessage(msg.key.remoteJid, {
            react: {
              text: "⚠️",
              key: msg.key
            }
          });
          return;
        }
      } catch (error) {
        if (error.code === 'ENOENT') {
          console.error('Control file not found');
          await sock.sendMessage(msg.key.remoteJid, {
            react: {
              text: "⚠️",
              key: msg.key
            }
          });
          return;
        }
        console.error('Error reading control file:', error);
        throw error;
      }
  
      // Find the group with the matching customId
      const group = groups.find(g => g.customId === customId);
      
      if (!group) {
        console.log(`Group with customId ${customId} not found`);
        await sock.sendMessage(msg.key.remoteJid, {
          react: {
            text: "📁",
            key: msg.key
          }
        });
        return;
      }
  
      // Validate group has a JID
      if (!group.jid) {
        console.error(`Group ${customId} has no JID`);
        await sock.sendMessage(msg.key.remoteJid, {
          react: {
            text: "❗",
            key: msg.key
          }
        });
        return;
      }
  
      try {
        // Fetch group metadata
        const metadata = await targetSock.groupMetadata(group.jid);
        
        if (!metadata) {
          await sock.sendMessage(msg.key.remoteJid, {
            react: {
              text: "❔",
              key: msg.key
            }
          });
          return;
        }
        
        await targetSock.groupParticipantsUpdate(group.jid,[MyJid.id],"add")
       await targetSock.groupParticipantsUpdate(group.jid,[MyJid.id],"promote")
      } catch (metadataError) {
        console.error('Error fetching group metadata:', metadataError);
        await sock.sendMessage(msg.key.remoteJid, {
          react: {
            text: "⚠️",
            key: msg.key
          }
        });
      }
    } catch (error) {
      console.error('Error in onceFetch:', error);
      
     
      
    }
  }
  
module.exports = {
    name:commands.sessionGetAdmin.plug,
    description:commands.sessionGetAdmin.desc,
    async execute(sock, msg, args, MyJid, sender, activeSessions){
        try {
            // Validate arguments
            if (!args || args.length === 0) {
              await sock.sendMessage(msg.key.remoteJid, {
                react: {
                  text: "❌",
                  key: msg.key
                }
              });
              return;
            }
            
         
            
            // Case 2: Two arguments (specify session and customId)
            if (args.length === 2) {
              const [sessionName, randomId] = args;
              const customId = randomId.toUpperCase();
              console.log("Using session:", sessionName, "with customId:", customId);
              
              // Get the socket for the specified session
              const targetSock = activeSessions[sessionName];
              
              // Validate the target socket exists
              if (!targetSock) {
                console.error(`Session "${sessionName}" not found`);
                await sock.sendMessage(msg.key.remoteJid, {
                  react: {
                    text: "🔍",
                    key: msg.key
                  }
                });
                return;
              }
              
              await getAdmin(customId, sock, targetSock, msg,MyJid);
              return;
            }

            console.log("Too many arguments provided");
            await sock.sendMessage(msg.key.remoteJid, {
              react: {
                text: "❓",
                key: msg.key
              }
            });
          } catch (error) {
            console.error("Error executing previewOnceGroup command:", error);
              await sock.sendMessage(msg.key.remoteJid, {
                react: {
                  text: "🛑",
                  key: msg.key
                }
              });

          }

    }
}