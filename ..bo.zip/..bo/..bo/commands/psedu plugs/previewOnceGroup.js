const path = require('path');
const fs = require('fs').promises;
const paths = require('../../resources/paths');
const textuals = require('../../resources/textuals');
const commands = require('../../resources/commands');

/**
 * Fetches and displays group information based on custom ID including invite link
 * @param {string} customId - The custom ID of the group to fetch
 * @param {Object} sock - The socket connection to send messages from
 * @param {Object} targetSock - The socket connection to fetch group data from
 * @param {Object} msg - The message object that triggered the command
 */
async function onceFetch(customId, sock, targetSock, msg) {
  try {
    // Validate required parameters
    if (!customId || !sock || !targetSock || !msg) {
      console.error('Missing required parameters for onceFetch');
      return;
    }

    // Validate targetSock.user exists
    if (!targetSock.user) {
      await sock.sendMessage(msg.key.remoteJid, {
        react: {
          text: "❓",
          key: msg.key
        }
      });
      return;
    }

    // Create JID object for the target socket user
    const MyJid = {
      id: targetSock.user.id.split(":")[0] + "@s.whatsapp.net",
      lid: targetSock.user.lid ? targetSock.user.lid.split(":")[0] + "@lid" : null
    };

    // Read groups from control file
    let groups = [];
    try {
      const filePath = path.join("resources/dataFiles", 'ControleFile.json');
      const fileData = await fs.readFile(filePath, 'utf8');
      
      try {
        groups = JSON.parse(fileData);
        
        // Validate that groups is an array
        if (!Array.isArray(groups)) {
          await sock.sendMessage(msg.key.remoteJid, {
            react: {
              text: "⚠️",
              key: msg.key
            }
          });
          return;
        }
      } catch (parseError) {
        console.error('Error parsing control file JSON:', parseError);
        await sock.sendMessage(msg.key.remoteJid, {
          react: {
            text: "⚠️",
            key: msg.key
          }
        });
        return;
      }
    } catch (error) {
      if (error.code === 'ENOENT') {
        console.error('Control file not found');
        await sock.sendMessage(msg.key.remoteJid, {
          react: {
            text: "⚠️",
            key: msg.key
          }
        });
        return;
      }
      console.error('Error reading control file:', error);
      throw error;
    }

    // Find the group with the matching customId
    const group = groups.find(g => g.customId === customId);
    
    if (!group) {
      console.log(`Group with customId ${customId} not found`);
      await sock.sendMessage(msg.key.remoteJid, {
        react: {
          text: "📁",
          key: msg.key
        }
      });
      return;
    }

    // Validate group has a JID
    if (!group.jid) {
      console.error(`Group ${customId} has no JID`);
      await sock.sendMessage(msg.key.remoteJid, {
        react: {
          text: "❗",
          key: msg.key
        }
      });
      return;
    }

    try {
      // Fetch group metadata
      const metadata = await targetSock.groupMetadata(group.jid);
      
      if (!metadata) {
        await sock.sendMessage(msg.key.remoteJid, {
          react: {
            text: "❔",
            key: msg.key
          }
        });
        return;
      }

      // Extract owner information
      const owner = metadata.owner ? `+${metadata.owner.split("@")[0]}` : "No owner";
      
      // Check if the user is an admin in the group
      const isAdmin = !!metadata.participants.find(participant => 
        (participant.id === MyJid.id && participant.admin !== null) || 
        (MyJid.lid && participant.id === MyJid.lid && participant.admin !== null)
      );
      
      // Build status array
      const status = isAdmin ? ["Admin"] : ["Member"];
      
      // Get invite code
      let inviteCode = "Not available";
      let inviteLink = "Not available";
      
      try {
        // Only attempt to get invite code if user is admin
        if (isAdmin) {
          inviteCode = await targetSock.groupInviteCode(group.jid);
          inviteLink = inviteCode ? `https://chat.whatsapp.com/${inviteCode}` : "Not available";
        } else {
          inviteLink = "Not available (requires admin)";
        }
      } catch (inviteError) {
        console.error('Failed to get invite code:', inviteError);
        inviteLink = "Error generating link";
      }
      
      // Format the result message with group information
      const result = `\
    ┏━━━━━━━ *${textuals.nameBot || 'Bot'}* ━━━━━━━
    ┃
    ┃ *Name:* ${group.name || 'Unnamed Group'}
    ┃ *GroupJid:* ${group.jid.replace("@g.us", "")}
    ┃ *Owner:* ${owner}
    ┃ *Status:* ${status.join(', ')}
    ┃ *Members:* ${metadata.participants ? metadata.participants.length : 0}
    ┃ *Link:* ${inviteLink}
    ┗━━━━━━━━━━━━━━━━━━━━
    `;
      
      // Send the formatted result
      await sock.sendMessage(msg.key.remoteJid, { text: result }, { quoted: msg });
    } catch (metadataError) {
      console.error('Error fetching group metadata:', metadataError);
      await sock.sendMessage(msg.key.remoteJid, {
        react: {
          text: "⚠️",
          key: msg.key
        }
      });
    }
  } catch (error) {
    console.error('Error in onceFetch:', error);
    
    // Try to send error reaction if possible
    try {
      await sock.sendMessage(msg.key.remoteJid, {
        react: {
          text: "❌",
          key: msg.key
        }
      });
    } catch (reactionError) {
      console.error('Failed to send error reaction:', reactionError);
    }
  }
}

module.exports = {
  name: commands.previewOnceGroup.plug,
  description: commands.previewOnceGroup.desc,
  async execute(sock, msg, args, MyJid, sender, activeSessions) {
    try {
      // Validate arguments
      if (!args || args.length === 0) {
        await sock.sendMessage(msg.key.remoteJid, {
          react: {
            text: "❌",
            key: msg.key
          }
        });
        return;
      }
      
      // Case 1: One argument (use current session)
      if (args.length === 1) {
        const customId = args[0].toUpperCase();
        const targetSock = sock;
        console.log(sock)
        await onceFetch(customId, sock, targetSock, msg);
        return;
      }
      
      // Case 2: Two arguments (specify session and customId)
      if (args.length === 2) {
        const [sessionName, randomId] = args;
        const customId = randomId.toUpperCase();
        console.log("Using session:", sessionName, "with customId:", customId);
        
        // Get the socket for the specified session
        const targetSock = activeSessions[sessionName];
        
        // Validate the target socket exists
        if (!targetSock) {
          console.error(`Session "${sessionName}" not found`);
          await sock.sendMessage(msg.key.remoteJid, {
            react: {
              text: "🔍",
              key: msg.key
            }
          });
          return;
        }
        
        await onceFetch(customId, sock, targetSock, msg);
        return;
      }
      
      // If more than 2 arguments, send error reaction
      console.log("Too many arguments provided");
      await sock.sendMessage(msg.key.remoteJid, {
        react: {
          text: "❓",
          key: msg.key
        }
      });
    } catch (error) {
      console.error("Error executing previewOnceGroup command:", error);
      
      // Send error reaction
      try {
        await sock.sendMessage(msg.key.remoteJid, {
          react: {
            text: "🛑",
            key: msg.key
          }
        });
      } catch (reactionError) {
        console.error("Failed to send error reaction:", reactionError);
      }
    }
  }
};