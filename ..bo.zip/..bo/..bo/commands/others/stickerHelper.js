const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");

module.exports = {
    name: commands.stickerHelper.plug,
    description: commands.stickerHelper.desc,
    async execute(sock, msg, args) {
        try {
            const helpText = `*•┈┈┈┈•✧✿✧•┈┈┈┈•*
*✨ Text Sticker Creator ✨*
*•┈┈┈┈•✧✿✧•┈┈┈┈•*

🔰 *Basic Usage:*
\`\`\`
textsticker [text] [preset] [text color] [bg color] [font size] [font type]
\`\`\`

🎨 *Advanced Usage:*
\`\`\`
textsticker [text] [preset] [text color] [bg color] [font size] [font type] [border width] [border color] [shadow blur] [shadow color] [shadow-x] [shadow-y] [shape] [text effect] [text opacity] [background style] [emoji]
\`\`\`

✅ *Preset Styles:*
■ default   ■ neon     ■ vintage
■ minimal   ■ elegant  ■ bold
■ dark

🔤 *Font Types:*
• Arabic Fonts:
  ■ amiri    ■ tajawal  ■ cairo
  ■ scheherazade  ■ harmattan   ■ dubai
  ■ noto     ■ droid

• English Fonts:
  ■ roboto   ■ opensans  ■ lato
  ■ montserrat  ■ poppins   ■ raleway
  ■ ubuntu    ■ playfair   ■ merriweather
  ■ sourcesans   ■ oswald   ■ comicsans
  ■ times   ■ georgia  ■ helvetica
  ■ arial   ■ verdana

🌈 *Color Options:*
■ red       ■ green     ■ blue
■ yellow    ■ cyan      ■ magenta
■ black     ■ white     ■ gray/grey
■ purple    ■ pink      ■ orange
■ brown     ■ violet    ■ gold
■ silver    ■ navy      ■ teal
■ maroon    ■ lime      ■ olive
■ aqua      ■ indigo    ■ turquoise
■ skyblue   ■ tomato    ■ crimson
■ darkblue  ■ darkgreen ■ darkred
■ darkgray  ■ lightgray ■ lightblue
■ lightgreen  ■ lightred  ■ transparent

🔶 *Shape Options:*
■ rounded   ■ square    ■ circle
■ oval      ■ roundedsquare

✨ *Text Effects:*
■ none      ■ glow      ■ distressed
■ outline

🖼️ *Background Styles:*
■ solid     ■ paper     ■ gradient

⚙️ *Extra Options:*
• Add "showdate" or "showtime" to show date/time
• Add emoji at the end for decoration

📝 *Examples:*
1. \`\`\`textsticker [Hello World] [neon] [white] [black] [45] [poppins]\`\`\`
2. \`\`\`textsticker [مرحبا بالعالم] [elegant] [darkblue] [lightgray] [36] [cairo] [1] [gray] [1] [#AA4141] [1] [1] [rounded] [none] [1] [solid] [😊]\`\`\`

*•┈┈┈┈•✧✿✧•┈┈┈┈•*`;

            await sock.sendMessage(msg.key.remoteJid, {
                text: helpText
            });
            
        } catch (error) {
            console.error("Error in textstickerhelp command:", error);
        }
    }
};