const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");
module.exports = {
    name: commands.groupsList.plug,
    description: commands.groupsList.desc,
    async execute(sock, msg, args) {
        try {
            const groups = await sock.groupFetchAllParticipating();
            
            // If no groups found
            if (Object.keys(groups).length === 0) {
                return await sock.sendMessage(msg.key.remoteJid, { 
                    text: "『 ❌ 』 *Bot is not in any groups currently!*" 
                });
            }
            let groupList = Object.values(groups)
                .map((g, index) => `*${index + 1}.* 『 👥 』 *${g.subject}*\n    └─ \`${g.id}\``)
                .join("\n\n");
            const totalGroups = Object.keys(groups).length;
            const message = `*┏━━━『 📋 GROUPS LIST 📋 』━━━┓*\n\n` + 
                          `*Total Groups:* ${totalGroups}\n\n` +
                          `${groupList}\n\n` +
                          `*┗━━━━━━━━━━━━━━━━━━━━━━━━━┛*`;
            
            await sock.sendMessage(msg.key.remoteJid, { text: message });
            
        } catch (error) {
            console.error(error);
        }
    }
};