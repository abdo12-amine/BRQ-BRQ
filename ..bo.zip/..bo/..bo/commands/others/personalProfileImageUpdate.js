const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");
const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const fs = require('fs');
const path = require('path');

module.exports = {
    name: commands.personalProfileImageUpdate.plug,
    description: commands.personalProfileImageUpdate.desc,
    async execute(sock, msg, args) {
        try {
            if (!msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                return;
            }

            const quotedMsg = msg.message.extendedTextMessage.contextInfo;
            let type = Object.keys(quotedMsg.quotedMessage)[0];
            
            if (type !== 'imageMessage') {
                return;
            }
            const logger = {
                info: (...args) => console.log(...args),
                debug: (...args) => console.debug(...args),
                warn: (...args) => console.warn(...args),
                error: (...args) => console.error(...args)
            };
            
            const message = {
                key: {
                    remoteJid: msg.key.remoteJid,
                    id: quotedMsg.stanzaId
                },
                message: quotedMsg.quotedMessage
            };
            
            const buffer = await downloadMediaMessage(
                message,
                'buffer',
                {},
                {
                    logger,
                    reuploadRequest: sock.updateMediaMessage
                }
            );
            const tempDir = path.join(__dirname, '../../temp');
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
            }
            const tempFilePath = path.join(tempDir, `profile_pic_${Date.now()}.jpg`);
            fs.writeFileSync(tempFilePath, buffer);
            await sock.updateProfilePicture(sock.user.id, {
                url: tempFilePath
            });
            fs.unlinkSync(tempFilePath);
        } catch (error) {
            console.log(error);
        }
    }
};