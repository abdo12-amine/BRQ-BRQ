const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");
module.exports = {
    name: commands.getProfileImg.plug,
    description: commands.getProfileImg.desc,
    async execute(sock, msg, args) {
        try {
            if (!msg.message?.extendedTextMessage?.contextInfo) {
                return;
            }
            const participantJid = msg.message.extendedTextMessage.contextInfo.participant;

            
            if (!participantJid) {
                return;
            }
            const ppUrl = await sock.profilePictureUrl("participantJid", 'image')
                .catch(error => {
                    return null;
                });

            if (!ppUrl) {
                return;
            }
            await sock.sendMessage(msg.key.remoteJid, {
                image: { url: ppUrl },
                caption: '> 𝙶𝚎𝚗𝚎𝚛𝚊𝚝𝚎𝚍 𝙱𝚢 : *𝐃𝐓𝐍*'
            });
        } catch (error) {
            console.log(error);
        }
    }
};