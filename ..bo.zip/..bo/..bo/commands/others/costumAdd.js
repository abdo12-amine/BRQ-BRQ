const path = require('path');
const fs = require('fs/promises');
const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");

module.exports = {
    name: commands.costumAdd.plug,
    description: commands.costumAdd.desc,
    async execute(sock, msg, args) {
        // Check if nickname is provided
        if (args.length === 0) {
            await sock.sendMessage(msg.key.remoteJid, { text: textuals.noNickname || "Please provide a nickname." });
            return;
        }
        
        try {
            const nickname = args[0];
            const contactsPath = path.join(__dirname, paths.contacts);
            let contacts = {};
            
            try {
                const fileData = await fs.readFile(contactsPath, 'utf8');
                contacts = JSON.parse(fileData);
            } catch (error) {
                return;
            }
            
            if (!contacts[nickname]) {
                return;
            }
            
            const userJid = contacts[nickname];
            const metadata = await sock.groupMetadata(msg.key.remoteJid);
            const groupMembers = metadata.participants.map(participant => participant.id);
            const isMember = groupMembers.includes(userJid);
            
            if (isMember) {

                return;
            }
            try {
                await sock.groupParticipantsUpdate(msg.key.remoteJid, [userJid], "add");
                const newMetadata = await sock.groupMetadata(msg.key.remoteJid);
                const newMembers = newMetadata.participants.map(participant => participant.id);
                if (newMembers.includes(userJid)) {
                   
                     return;
                }else{
                     const inviteCode = await sock.groupInviteCode(msg.key.remoteJid);
                     await sock.sendMessage(userJid, {
                        text: `*follow this link:* https://chat.whatsapp.com/${inviteCode}`,
                    });
                    await sock.sendMessage(msg.key.remoteJid, {react: { text: "🔗", key: msg.key } });
                    
                }
               

              
            } catch (error) {
                console.error("Error adding participant:", error);
            }
   
        } catch (error) {
            console.error("Error in costumAdd command:", error);
        }
    }
};
