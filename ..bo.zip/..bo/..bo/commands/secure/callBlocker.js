const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");

let antiCall = "off";
let listenerRegistered = false;

module.exports = {
    name: commands.antiCall.plug,
    description: commands.antiCall.desc,

    async execute(sock, msg, args, MyJid) {
        if (!args || args.length === 0) return;

        if (args[0] === "on") {
            if (antiCall === "on") return;

            antiCall = "on"; 
            await sock.sendMessage(msg.key.remoteJid, {
                react: {
                    text: "✅",
                    key: msg.key
                }
            });

        } else if (args[0] === "off") {
            if (antiCall === "off") return;

            antiCall = "off"; 
            await sock.sendMessage(msg.key.remoteJid, {
                react: {
                    text: "⛔",
                    key: msg.key
                }
            });

        } else {
            await sock.sendMessage(msg.key.remoteJid, {
                react: {
                    text: "⚠️",
                    key: msg.key
                }
            });
        }

        if (!listenerRegistered) {
            registerXModeListener(sock, MyJid);
            listenerRegistered = true;
        }
    }
};

function registerXModeListener(sock, MyJid) {
    sock.ev.on("call", async (callData) => {
        if (antiCall === "off") return;

        const callerId = callData[0]?.from;
        if (callerId) {
            await sock.rejectCall(callData[0].id, callData[0].from);
        }
    });
}
