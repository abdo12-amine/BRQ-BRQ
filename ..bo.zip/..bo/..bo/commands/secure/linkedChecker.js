const textuals = require("../../resources/textuals");
const commands =require("../../resources/commands");
async function checkIfLInked(sock , msg , jid ,args,MyJid) {
    const privateSend = args.length === 1 && args[0] === "prv";
    const devices = await sock.getUSyncDevices([jid], true);
    const DevicesLength = devices.length - 1; 
    console.log(DevicesLength);
    let toJid = [];
   if(privateSend && !msg.key.remoteJid.endsWith("@g.us")){
     toJid = MyJid.id
   }
   if(!privateSend){
     toJid = msg.key.remoteJid
   }
    await sock .sendMessage(toJid, {
           text: `*${DevicesLength}* 𝗯𝗼𝘁(𝘀) 𝗹𝗶𝗻𝗸𝗲𝗱 𝘁𝗼 𝘁𝗵𝗶𝘀 𝗻𝘂𝗺𝗯𝗲𝗿 !!`,
    });
}
module.exports = {
       name : commands.getLinkedDevices.plug,
       description: commands.getLinkedDevices.desc,
       async execute(sock,msg,args,MyJid){
                     try {
                        if(msg.key.remoteJid.endsWith("@g.us")){
                            const isReply = msg.message.extendedTextMessage?.contextInfo?.quotedMessage
                            const isMention = msg.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                            if(isReply){
                                const jid = msg.message.extendedTextMessage?.contextInfo?.participant;
                                await checkIfLInked(sock , msg , jid, args,MyJid);
                                return;
                            }
                            if(isMention.length = 1){
                                const jid = msg.message.extendedTextMessage?.contextInfo?.mentionedJid[0];
                                await checkIfLInked(sock , msg , jid,args,MyJid);
                                return;
                            }
                            return;
                              }
                              const jid = msg.key.remoteJid;
                              await checkIfLInked(sock , msg , jid,args,MyJid);
                     } catch (error) {
                     console.log(error) 
                     } 
                    
       }
};
       