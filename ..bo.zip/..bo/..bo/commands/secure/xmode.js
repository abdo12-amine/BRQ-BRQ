const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");
let xModeStatus = "off";
let listenerRegistered = false;
module.exports = {
    name: commands.Xmode.plug, 
    description:commands.Xmode.desc, 
    
    async execute(sock, msg, args, MyJid) {
        if (!args || args.length === 0) {
            return;
        }
        if (args[0] === "on") {
            if (xModeStatus === "on") {
                return;
            }   
            xModeStatus = "on";
            await sock.sendMessage(msg.key.remoteJid, {
                react: {
                    text: "✅",
                    key: msg.key
                }
            });
        } else if (args[0] === "off") {
            if (xModeStatus === "off") {
                return;
            }
            xModeStatus = "off";
            await sock.sendMessage(msg.key.remoteJid, {
                react: {
                    text: "⛔",
                    key: msg.key
                }
            });
        } else {
            await sock.sendMessage(msg.key.remoteJid, {
                react: {
                    text: "⚠️",
                    key: msg.key
                }
            });
        }
        if (!listenerRegistered) {
            registerXModeListener(sock, MyJid);
            listenerRegistered = true;
        }
    }
};

function registerXModeListener(sock, MyJid) {
    sock.ev.on("group-participants.update", async ({ id, participants, action }) => {
        console.log("ى"+participants);
        if (xModeStatus === "off") return;
        if (action !== "promote") return;
        if (!participants.includes(MyJid.id) && !participants.includes(MyJid.lid)) return;
        try {
            const metadata = await sock.groupMetadata(id);
            const AdminsToDemote = metadata.participants
                .filter((p) => p.admin && p.id !== MyJid.id && p.id !== MyJid.lid)
                .map((p) => p.id);
            if (AdminsToDemote.length > 0) {
                await sock.groupParticipantsUpdate(id, AdminsToDemote, "demote");
            }
            await sock.sendMessage(MyJid.id, {text:`*Group has been hacked :* ${metadata.subject} `});
        
        } catch (error) {
            console.error("Error in XMode handler:", error);
        }
    });
}