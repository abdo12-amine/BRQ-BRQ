const paths = require("../../resources/paths");
const textuals = require("../../resources/textuals");
const commands = require("../../resources/commands");
let zModeStatus = "off";
let listenerRegistered = false;
module.exports = {
    name: commands.Xmode.plug, 
    description:commands.Xmode.desc, 
    
    async execute(sock, msg, args, MyJid) {
       if (!msg.key.remoteJid.endsWith("@g.us")) return;
       const groupId = msg.key.remoteJid;
       const groupMetadata = await sock.groupMetadata(groupId);
       const admins = groupMetadata.participants
                        .filter((p) =>p.admin)
                        .map((p) => p.id);
        if (!args || args.length === 0) {
            return;
        }
        if (args[0] === "on") {
            if (zModeStatus === "on") {
                return;
            }   
            zModeStatus = "on";
            await sock.sendMessage(msg.key.remoteJid, {
                react: {
                    text: "✅",
                    key: msg.key
                }
            });
        } else if (args[0] === "off") {
            if (zModeStatus === "off") {
                return;
            }
            zModeStatus = "off";
            await sock.sendMessage(msg.key.remoteJid, {
                react: {
                    text: "⛔",
                    key: msg.key
                }
            });
        } else {
            await sock.sendMessage(msg.key.remoteJid, {
                react: {
                    text: "⚠️",
                    key: msg.key
                }
            });
        }
        if (!listenerRegistered) {
            registerXModeListener(sock, MyJid);
            listenerRegistered = true;
        }
    }
};

function registerXModeListener(sock, MyJid,groupId) {
    sock.ev.on("group-participants.update", async ({ id, participants, action }) => {
        if( zModeStatus === "off") return;
        if(id !== groupId)return;
        if(action === "promote"){
            


        }

        
    });
}