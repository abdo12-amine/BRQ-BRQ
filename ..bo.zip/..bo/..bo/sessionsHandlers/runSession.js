const commmnds = require("../resources/commands");
const fs = require("fs");
const path = require("path");
const { isSessionFolderEmpty } = require("../index");
const commands = require("../resources/commands");

const SESSIONS_DIR = "sessions";

module.exports = {
  name: commands.runSession.plug,
  execute: async (
    sock,
    msg,
    args,
    MyJid,
    sender,
    activeSessions,
    sessionsToNotReconnect,
    startBotInstance,
    pendingSessions,
    isSessionFolderEmpty
  ) => {
    const sessionName = sock.sessionName;

    if (args.length === 0) {
      await sock.sendMessage(msg.key.remoteJid, {
        text: "⚠️ 𝗔𝗱𝗱 𝗻𝗮𝗺𝗲 𝗼𝗳 𝘀𝗲𝘀𝘀𝗶𝗼𝗻 𝘁𝗼 𝗿𝘂𝗻 𝗶𝘁",
      });
      return;
    }

    const runSessionName = args[0];
    const sessionFolder = path.join(SESSIONS_DIR, runSessionName);

    if (activeSessions[runSessionName]) {
      await sock.sendMessage(msg.key.remoteJid, {
        text: `𝗦𝗲𝘀𝘀𝗶𝗼𝗻 𝗮𝗹𝗿𝗲𝗮𝗱𝘆 𝗿𝘂𝗻𝗻𝗶𝗻𝗴 : ${runSessionName}`,
      });
      return;
    }

    if (!fs.existsSync(sessionFolder)) {
      await sock.sendMessage(msg.key.remoteJid, {
        text: `𝗦𝗲𝘀𝘀𝗶𝗼𝗻 𝗻𝗼𝘁 𝗳𝗼𝘂𝗻𝗱 : ${runSessionName}`,
      });
      return;
    }

    if (isSessionFolderEmpty(sessionFolder)) {
      await sock.sendMessage(msg.key.remoteJid, {
        text: `𝘀𝗲𝘀𝘀𝗶𝗼𝗻 𝗶𝘀 𝗲𝗺𝗽𝘁𝘆 :${runSessionName}`,
      });
      return;
    }
    try {
      await startBotInstance(runSessionName);
      await sock.sendMessage(msg.key.remoteJid, {
        text: `𝗦𝗲𝘀𝘀𝗶𝗼𝗻 𝘀𝘁𝗮𝗿𝘁𝗲𝗱 𝘀𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆 : ${runSessionName}`,
      });
    } catch (error) {
      console.error(`[${sessionName}] Error starting session '${runSessionName}':`, error);

    }
  },
};