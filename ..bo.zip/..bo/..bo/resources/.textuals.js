const textuals = {
  takeover: {
    name: "مزروف 𝑽𝑬𝑴",
    description: `𝐒𝐀𝐍𝐉𝐈 eats your group 🫦🤙
عبدالله هو نفسه 𝐒𝐀𝐍𝐉𝐈 بس الفرق انه تاب وكذا فاهمين كيف؟

---

تبي تعرفوا كيف اتبعبصتو؟ كل شي ينعرض هنا:

𝑽𝑬𝑴🍷

𓆩⚘𓆪━━━━𓆩★𓆪━━━━𓆩⚘𓆪

𝗪𝗘𝗟𝗖𝗢𝗠𝗘 𝗧𝗢 𝗠𝗬 𝗦𝗛𝗢𝗪🍷⃟‌⃟❦

*⧉ ┇↫𝗟𝗘𝗔𝗗𝗘𝗥 /𝗦𝗔𝗡𝗝𝗜⚡

*⧉ ┇↫𝗔𝗦𝗦𝗜𝗦𝗧𝗔𝗡𝗧/

*⧉ ┇↫𝗧𝗘𝗔𝗠/
𓆩⚘𓆪━━━━𓆩★𓆪━━━━𓆩⚘𓆪
⧉ ┇↫فعاليات - مسابقات - جوائز..

⧉ ┇↫تتعلم كيف تزرف ايا غروب على واتساب..

⧉ ┇↫تبادلات مفتوحة  عند المشرفين و النشر الديني بدون مقابل..

⧉ ┇↫نعطيكم اكواد بوتات ونسوي مسابقات على ارقام..

⧉ ┇↫ شروحات عن البوتات وكثير اشياء..

𓆩⚘𓆪━━━━𓆩★𓆪━━━━𓆩⚘𓆪

✦ روابط الصحيفة (𝑽𝑬𝑴)
➤ 𝑽𝑬𝑴 ➊ : 𝑽𝑬𝑴🍷⃟‌⃟❦صـحـيـفـة
https://chat.whatsapp.com/JkLlb01FKfKCMFM0N3XAQ5?mode=ac_t

➤ 𝑽𝑬𝑴 ➋ : 𝑺𝑨𝑵𝑱𝑰/𝑽𝑬𝑴🍷⃟‌⃟❦صـحـيـفـة
https://chat.whatsapp.com/KF5yVsKRqgo8y4VoPqkmm7?mode=ac_t

➤ 𝑽𝑬𝑴 ➌ : 𝑽𝑬𝑴🍷⃟‌⃟❦𝑪𝑯𝑨𝑻
https://chat.whatsapp.com/B7cl8vFJ2r6JK7rJ4b5VTA?mode=ac_t

➤ 𝑽𝑬𝑴 ➍ : 『𝑉𝐸𝑁𝑅𝑂/𝑽𝑬𝑴』⊰🖋️⊱ ‏صـحـيـفـة ┊ 復讐
https://chat.whatsapp.com/J59LYc9E4RL1C43MYiQkKh?mode=ac_t

➤ 𝑽𝑬𝑴 ➎ : ┆ ❒ 𝐕𝐄𝐍𝐑𝐎/𝑽𝑬𝑴❒ ┆⇚ 𝑪𝑯𝑨𝑻
https://chat.whatsapp.com/FZKwK5l4oKu9lEOuTYb2xP?mode=ac_t

➤ 𝑽𝑬𝑴 ➏ : مــزروف|𝑽𝑬𝑴1
https://chat.whatsapp.com/Ei19S6WMgRpK6vq4slvIIc?mode=ac_t

➤ 𝑽𝑬𝑴 ➐ : مــزروف|𝑽𝑬𝑴2
https://chat.whatsapp.com/GTHcUrym2tN02R7ynMVk4J?mode=ac_t

➤ 𝑽𝑬𝑴 ➑ : 𝒀𝑶𝑯𝑨𝑩𝑨𝑪𝑯/𝑽𝑬𝑴❄️صَحِيفَة
https://chat.whatsapp.com/J9FYzw56dcnACO78WZNEVL?mode=ac_t

➤ 𝑽𝑬𝑴 ➒ :
➤ 𝑽𝑬𝑴 ➓ : رابط المنفى
➤ 𝑽𝑬𝑴  : الرابط الأخير - بوابة النهاية

𓆩⚘𓆪━━━━𓆩★𓆪━━━━𓆩⚘𓆪

𖤓˖⁺‧₊☽𓅨☾₊‧⁺˖𖤓 𝓝𝓸𝓽𝓱𝓲𝓷𝓰 𝓵𝓪𝓼𝓽𝓼 𝓾𝓷𝓽𝓲𝓵 𝓽𝓱𝓮 𝓼𝓾𝓷 𝓫𝓻𝓮𝓪𝓴𝓼 𝓽𝓱𝓮 𝓵𝓪𝔀 𝓸𝓷𝓮 𝓭𝓪𝔂 𝓪𝓷𝓭 𝓻𝓲𝓼𝓮𝓼 𝓲𝓷 𝓽𝓱𝓮 𝔀𝓮𝓼𝓽 𝓽𝓸 𝓪𝓷𝓷𝓸𝓾𝓷𝓬𝓮 𝓽𝓱𝓮 𝓮𝓷𝓭.🍷
𓆩⚘𓆪━━━━𓆩★𓆪━━━━𓆩⚘𓆪

𝑽𝑬𝑴🍷⃟‌⃟❦صحيفة`,
  },

  nameBot: "𝐇𝟒𝐗",

  mentionsWord: {
    text: "*𝗠𝗲𝗻𝘁𝗶𝗼𝗻𝗻𝗲𝗱 𝗕𝘆 𝑺𝑨𝑵𝑱𝑰*",
  },

  testBot: {
    text: "> ⎯⎯   ✦ 𝐒𝐀𝐍𝐉𝐈 𝐀𝐓𝐒𝐇𝐀𝐍 𝐈𝐒 𝐖𝐎𝐑𝐊𝐈𝐍𝐆 🪐 ✦ ⎯",
  },

  stikerMaker: {
    right: "𝐒𝐀𝐍𝐉𝐈",
  },

  antiImageViewOnce: {
    right: "> 𝙶𝚎𝚗𝚎𝚛𝚊𝚝𝚎𝚍 𝙱𝚢 : 𝐒𝐀𝐍𝐉𝐈",
  },
};

module.exports = textuals;