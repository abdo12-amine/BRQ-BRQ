const fs = require('fs');
const paths = require("../../resources/paths");

async function  updateKickedCount(NumOfKicked) {
       try{
              let kickedCount = 0 ;

              try {
                     const data = await fs.promises.readFile(paths.personalStatics,'utf8');
                     const parsedData = JSON.parse(data);
                     kickedCount = parsedData.CountOfKicked || 0 ;
              } catch (error) {
                     console.error(error);
              }
              kickedCount += NumOfKicked;
              const updatedData = {
                     CountOfKicked:kickedCount
              };
              await fs.promises.writeFile(paths.personalStatics, JSON.stringify(updatedData, null, 2));
       }catch (error){
              console.error(error);

       }
};
module.exports = updateKickedCount;