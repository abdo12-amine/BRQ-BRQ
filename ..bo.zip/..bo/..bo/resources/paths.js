const paths = {
takeover:{
       Image:"resources/images/takeImg.jpeg",
},
personalStatics:"resources/dataFiles/personalStatics.json",
contacts:"../../resources/dataFiles/contacts.json",
elites:"./resources/dataFiles/elites.json",
safeGroups:"./resources/dataFiles/safeGroups.json",

};
module.exports = paths ;