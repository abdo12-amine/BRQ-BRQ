const textuals = {
  takeover: {
    name: "مزروف 𝑽𝑬𝑴",
    description: `𝐒𝐀𝐍𝐉𝐈 زرفكم و بس عاوزين ايه يعني؟ اه صح لا تنسا تحاول تبند رقمي معي غيره مليون 🫦  
المهم تبي تعرف كيف اتبعبصت؟ خش هنا:𖠇 𝐒𝐀𝐍𝐉𝐈↬ https://chat.whatsapp.com/JkLlb01FKfKCMFM0N3XAQ5?mode=r_c`,
  },

  nameBot: "𝐇𝟒𝐗",

  mentionsWord: {
    text: "*𝗠𝗲𝗻𝘁𝗶𝗼𝗻𝗻𝗲𝗱 𝗕𝘆 𝑺𝑨𝑵𝑱𝑰*",
  },

  testBot: {
    text: "> ⎯⎯   ✦ 𝐒𝐀𝐍𝐉𝐈 𝐀𝐓𝐒𝐇𝐀𝐍 𝐈𝐒 𝐖𝐎𝐑𝐊𝐈𝐍𝐆 🪐 ✦ ⎯",
  },

  stikerMaker: {
    right: "𝐒𝐀𝐍𝐉𝐈",
  },

  antiImageViewOnce: {
    right: "> 𝙶𝚎𝚗𝚎𝚛𝚊𝚝𝚎𝚍 𝙱𝚢 : 𝐒𝐀𝐍𝐉𝐈",
  },
};

module.exports = textuals;